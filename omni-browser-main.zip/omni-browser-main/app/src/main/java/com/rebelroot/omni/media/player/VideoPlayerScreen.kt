/*
 * Omni Browser - A premium, private, and secure web browser.
 * Copyright (C) 2026 RebelRoot Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.rebelroot.omni.media.player

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import android.app.PictureInPictureParams
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.util.Rational
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.rememberCoroutineScope
import com.rebelroot.omni.media.MediaInterceptor
import androidx.compose.material3.*
import androidx.compose.runtime.collectAsState
import com.rebelroot.omni.ai.asr.VoskAsrEngine
import com.rebelroot.omni.ai.captions.LiveCaptionEngine
import com.rebelroot.omni.ai.media.CaptionRenderersFactory
import com.rebelroot.omni.ai.media.PcmTeeAudioProcessor
import com.rebelroot.omni.ai.models.ModelInstallState
import com.rebelroot.omni.ai.models.ModelPlatform
import com.rebelroot.omni.ai.models.ModelState
import com.rebelroot.omni.ai.models.ModelZipExtractor
import java.io.File
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll


import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.res.stringResource
import com.rebelroot.omni.R

private enum class AspectMode { FIT, FILL, STRETCH }

private fun AspectMode.toResizeMode(): Int = when (this) {
    AspectMode.FIT     -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
    AspectMode.FILL    -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    AspectMode.STRETCH -> androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun VideoPlayerScreen(
    videoPath: String,
    referrerUrl: String = "",
    videoTitle: String = "",
    downloadEngine: com.rebelroot.omni.media.StreamDownloadEngine? = null,
    viewModel: com.rebelroot.omni.browser.BrowserViewModel? = null,
    onNavigateBack: () -> Unit
) {
    BackHandler {
        onNavigateBack()
    }
    val context = LocalContext.current
    val accentColor = Color(0xFF00A5C4)
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val originalDecodedPath = remember(videoPath) {
        if (videoPath.startsWith("http://") || videoPath.startsWith("https://") || videoPath.startsWith("/")) {
            videoPath
        } else {
            try {
                val decodedBytes = try {
                    android.util.Base64.decode(videoPath, android.util.Base64.URL_SAFE)
                } catch (e: Exception) {
                    android.util.Base64.decode(videoPath, android.util.Base64.DEFAULT)
                }
                String(decodedBytes, Charsets.UTF_8)
            } catch (e: Exception) {
                try {
                    java.net.URLDecoder.decode(videoPath, "UTF-8")
                } catch (e2: Exception) {
                    videoPath
                }
            }
        }
    }
    var decodedPath by remember(originalDecodedPath) { mutableStateOf(originalDecodedPath) }
    val youtubeVideoId = remember {
        val cleanUrl = if (decodedPath.contains("googlevideo.com") || decodedPath.contains("youtube.com") || decodedPath.contains("youtu.be")) decodedPath else referrerUrl
        getYouTubeVideoId(cleanUrl)
    }

    val isOnline = remember(decodedPath) { decodedPath.startsWith("http://") || decodedPath.startsWith("https://") }
    var downloadToLocker by remember { mutableStateOf(false) }
    val activity = remember(context) {
        var ctx = context
        while (ctx is android.content.ContextWrapper) {
            if (ctx is Activity) break
            ctx = ctx.baseContext
        }
        (ctx as? Activity) ?: com.rebelroot.omni.MainActivity.getActiveActivity()
    }
    val setWindowBrightness = { value: Float ->
        activity?.let { act ->
            act.runOnUiThread {
                try {
                    val lp = act.window.attributes
                    lp.screenBrightness = value.coerceIn(0.01f, 1f)
                    act.window.attributes = lp
                } catch (e: Exception) {
                    android.util.Log.e("VideoPlayer", "Failed to set window brightness", e)
                }
            }
        }
    }
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val coroutineScope = rememberCoroutineScope()

    var exoPlayerInstance by remember { mutableStateOf<ExoPlayer?>(null) }
    // Captured PlayerView reference so we can bind the player to the view
    // deterministically inside the player-init effect (see black-screen fix below).
    var playerViewRef by remember { mutableStateOf<PlayerView?>(null) }

    // ── Media Handoff (Phase 5-7): consume live state from website <video> ──
    // Priority: live handoff > persisted position > 0
    val handoff = remember { viewModel?.consumePendingHandoff(decodedPath) }
    var isPlaying by remember { mutableStateOf(!(handoff?.isPaused ?: false)) }
    var playbackPosition by remember {
        mutableLongStateOf(
            handoff?.currentPositionMs
                ?: viewModel?.getVideoPosition(decodedPath)
                ?: 0L
        )
    }
    var duration by remember { mutableLongStateOf(0L) }

    // Restore handoff-derived playback parameters
    var initialPlaybackRate by remember { mutableFloatStateOf(handoff?.playbackRate ?: 1.0f) }
    var initialVolume by remember { mutableFloatStateOf(handoff?.volume ?: 1.0f) }
    var initialMuted by remember { mutableStateOf(handoff?.muted ?: false) }
    
    // Gestures overlay states
    var brightness by remember { mutableFloatStateOf(0.5f) }
    var volume by remember { mutableFloatStateOf(0.5f) }
    var showGestureIndicator by remember { mutableStateOf(false) }
    var gestureIndicatorText by remember { mutableStateOf("") }
    var lastLeftTapTime by remember { mutableLongStateOf(0L) }
    var lastRightTapTime by remember { mutableLongStateOf(0L) }
    var leftTapJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var rightTapJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    var gestureIndicatorJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }


    var showControls by remember { mutableStateOf(true) }
    var isSeeking by remember { mutableStateOf(false) }
    var seekTargetPosition by remember { mutableLongStateOf(0L) }
    var sliderStartPos by remember { mutableLongStateOf(0L) }
    var isSliderScrubbing by remember { mutableStateOf(false) }

    // Aspect ratio mode: FIT (letterbox), FILL (crop), STRETCH (distort to fill)
    var aspectMode by remember { mutableStateOf(AspectMode.FIT) }

    val aspectFitText = stringResource(R.string.video_player_aspect_fit)
    val aspectFillText = stringResource(R.string.video_player_aspect_fill)
    val aspectStretchText = stringResource(R.string.video_player_aspect_stretch)

    val aspectLabel = when (aspectMode) {
        AspectMode.FIT -> aspectFitText
        AspectMode.FILL -> aspectFillText
        AspectMode.STRETCH -> aspectStretchText
    }

    // Downloader Quality Selector States
    var isFetchingQualities by remember { mutableStateOf(false) }
    var showQualitySelector by remember { mutableStateOf(false) }
    var qualityOptions by remember { mutableStateOf<List<VideoQualityOption>>(emptyList()) }

    var showSettingsDialog by remember { mutableStateOf(false) }
    var selectedSettingsTab by remember { mutableStateOf("Speed") }
    var showSnifferSubDialog by remember { mutableStateOf(false) }
    var currentSpeed by remember { mutableFloatStateOf(1.0f) }
    var audioTracks by remember { mutableStateOf<List<TrackOption>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<TrackOption>>(emptyList()) }
    var videoTracks by remember { mutableStateOf<List<TrackOption>>(emptyList()) }

    // ── Offline live captions (on-device ASR) ───────────────────────────────
    val captionPlatform = remember { ModelPlatform.get(context) }
    val captionRepoStates by captionPlatform.repository.states.collectAsState()
    val asrDescriptor = remember { captionPlatform.catalog.findForAsr(null).firstOrNull() }
    var captionActive by remember { mutableStateOf(false) }
    var captionBusy by remember { mutableStateOf(false) }
    var showCaptionModelDialog by remember { mutableStateOf(false) }
    var activeCaptionEngine by remember { mutableStateOf<LiveCaptionEngine?>(null) }

    // Tee from the Media3 audio sink into the caption engine (playback untouched).
    val captionTee = remember {
        PcmTeeAudioProcessor { bytes, sampleRate, channelCount ->
            activeCaptionEngine?.feedPcm(bytes, sampleRate, channelCount)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            activeCaptionEngine?.release()
            activeCaptionEngine = null
        }
    }

    val startOfflineCaptions: () -> Unit = {
        val desc = asrDescriptor
        when {
            desc == null -> Toast.makeText(context, "No offline caption model available", Toast.LENGTH_LONG).show()
            !captionPlatform.repository.isInstalled(desc) -> showCaptionModelDialog = true
            captionBusy -> Unit
            else -> {
                captionBusy = true
                Toast.makeText(context, "Starting offline captions…", Toast.LENGTH_SHORT).show()
                coroutineScope.launch {
                    try {
                        val extractDir = File(captionPlatform.storage.modelDir(desc.id), "extracted")
                        ModelZipExtractor.extract(captionPlatform.storage.finalFile(desc), extractDir)
                        val modelRoot = ModelZipExtractor.findModelRoot(extractDir)
                        val engine = LiveCaptionEngine(
                            asr = VoskAsrEngine(modelRoot),
                            clockMs = { exoPlayerInstance?.currentPosition ?: 0L }
                        )
                        activeCaptionEngine = engine
                        captionActive = true
                    } catch (e: Exception) {
                        android.util.Log.e("VideoPlayer", "Failed to start offline captions", e)
                        Toast.makeText(context, "Failed to start captions: ${e.message ?: "error"}", Toast.LENGTH_LONG).show()
                    } finally {
                        captionBusy = false
                    }
                }
            }
        }
    }

    val stopOfflineCaptions: () -> Unit = {
        activeCaptionEngine?.release()
        activeCaptionEngine = null
        captionActive = false
    }

    val updateTracksList = { player: Player ->
        val currentTracks = player.currentTracks
        val audioList = mutableListOf<TrackOption>()
        val subtitleList = mutableListOf<TrackOption>()
        val videoList = mutableListOf<TrackOption>()

        currentTracks.groups.forEachIndexed { groupIdx, group ->
            val type = group.type
            for (trackIdx in 0 until group.length) {
                if (group.isTrackSupported(trackIdx)) {
                    val format = group.getTrackFormat(trackIdx)
                    val lang = format.language ?: "unknown"
                    val label = when (type) {
                        androidx.media3.common.C.TRACK_TYPE_AUDIO -> format.label ?: "Audio Track #${audioList.size + 1} (${lang.uppercase()})"
                        androidx.media3.common.C.TRACK_TYPE_TEXT -> format.label ?: "Subtitle #${subtitleList.size + 1} (${lang.uppercase()})"
                        androidx.media3.common.C.TRACK_TYPE_VIDEO -> {
                            val h = format.height
                            val w = format.width
                            val labelStr = if (h > 0) "${h}p" else "${w}x${h}"
                            when {
                                h >= 2160 -> "$labelStr (4K Ultra HD)"
                                h >= 1440 -> "$labelStr (2K Quad HD)"
                                h >= 1080 -> "$labelStr (1080p Full HD)"
                                h >= 720 -> "$labelStr (720p HD)"
                                else -> labelStr
                            }
                        }
                        else -> "Track"
                    }
                    val option = TrackOption(
                        groupIndex = groupIdx,
                        trackIndex = trackIdx,
                        label = label,
                        isSelected = group.isTrackSelected(trackIdx),
                        mediaTrackGroup = group.mediaTrackGroup
                    )
                    if (type == androidx.media3.common.C.TRACK_TYPE_AUDIO) {
                        audioList.add(option)
                    } else if (type == androidx.media3.common.C.TRACK_TYPE_TEXT) {
                        subtitleList.add(option)
                    } else if (type == androidx.media3.common.C.TRACK_TYPE_VIDEO) {
                        videoList.add(option)
                    }
                }
            }
        }
        audioTracks = audioList
        subtitleTracks = subtitleList
        videoTracks = videoList.distinctBy { it.label }.sortedByDescending {
            it.label.replace(Regex("[^0-9]"), "").toIntOrNull() ?: 0
        }
    }

    val selectAudioTrack = { player: Player, option: TrackOption ->
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(
                androidx.media3.common.TrackSelectionOverride(
                    option.mediaTrackGroup,
                    option.trackIndex
                )
            )
            .build()
        updateTracksList(player)
    }

    val selectSubtitleTrack = { player: Player, option: TrackOption ->
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(
                androidx.media3.common.TrackSelectionOverride(
                    option.mediaTrackGroup,
                    option.trackIndex
                )
            )
            .build()
        updateTracksList(player)
    }

    val disableSubtitles = { player: Player ->
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
            .build()
        updateTracksList(player)
    }

    val selectAutoVideo = { player: Player ->
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_VIDEO)
            .build()
        updateTracksList(player)
    }

    val selectVideoTrack = { player: Player, option: TrackOption ->
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(
                androidx.media3.common.TrackSelectionOverride(
                    option.mediaTrackGroup,
                    option.trackIndex
                )
            )
            .build()
        updateTracksList(player)
    }



    val jobs by downloadEngine?.jobs?.collectAsState() ?: remember { mutableStateOf(emptyList()) }
    val currentJob = remember(jobs, decodedPath) {
        jobs.find { it.url == decodedPath }
    }
    val progressState = currentJob?.progress?.collectAsState()

    // Initialize brightness to current system level if available
    LaunchedEffect(Unit) {
        activity?.window?.attributes?.screenBrightness?.let {
            if (it >= 0f) brightness = it
        }
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
        volume = curVol / maxVol
    }

    // Auto-fade controls after 3 seconds of inactivity
    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            delay(3000)
            showControls = false
        }
    }

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    // Track that the player screen is active so MainActivity can auto-enter PiP on home-press
    // and enable edge-to-edge cutout display mode so video spans the full screen.
    DisposableEffect(Unit) {
        viewModel?.isVideoPlayerScreenActive = true
        activity?.let { act ->
            act.runOnUiThread {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                        val lp = act.window.attributes
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                        } else {
                            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                        }
                        act.window.attributes = lp
                    }
                } catch (_: Exception) {}
            }
        }
        onDispose {
            viewModel?.isVideoPlayerScreenActive = false
            activity?.let { act ->
                act.runOnUiThread {
                    try {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                            val lp = act.window.attributes
                            lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                            act.window.attributes = lp
                        }
                        val lp = act.window.attributes
                        lp.screenBrightness = -1f // BRIGHTNESS_OVERRIDE_NONE
                        act.window.attributes = lp
                    } catch (_: Exception) {}
                }
            }
        }
    }

    // Hide system bars when video controls are hidden (immersive playback),
    // show them when controls are visible so the user can see status/nav info.
    // Uses WindowInsetsController directly to avoid FullscreenManager's requestedOrientation
    // side-effect, which was creating an orientation feedback loop and crashing.
    LaunchedEffect(showControls) {
        activity?.let { act ->
            val window = act.window
            val decorView = window.decorView
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                val ctrl = decorView.windowInsetsController
                if (ctrl != null) {
                    if (!showControls) {
                        ctrl.hide(android.view.WindowInsets.Type.systemBars())
                        ctrl.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    } else {
                        ctrl.show(android.view.WindowInsets.Type.systemBars())
                    }
                }
            } else {
                val ctrl = androidx.core.view.WindowCompat.getInsetsController(window, decorView)
                if (!showControls) {
                    ctrl.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                    ctrl.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else {
                    ctrl.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
            }
        }
    }

    // Clean up orientation and system bars when leaving the player
    DisposableEffect(Unit) {
        onDispose {
            activity?.let { act ->
                act.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                // Restore system bars directly
                val window = act.window
                val decorView = window.decorView
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    decorView.windowInsetsController?.show(android.view.WindowInsets.Type.systemBars())
                } else {
                    androidx.core.view.WindowCompat.getInsetsController(window, decorView)
                        .show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
            }
        }
    }

    DisposableEffect(decodedPath, referrerUrl) {
        if (youtubeVideoId != null) {
            return@DisposableEffect onDispose {}
        }
        var exoPlayer: ExoPlayer? = null
        var lifecycleObserver: androidx.lifecycle.LifecycleEventObserver? = null

        try {
            val uri = if (decodedPath.startsWith("http://") || decodedPath.startsWith("https://")) {
                Uri.parse(decodedPath)
            } else {
                Uri.fromFile(java.io.File(decodedPath))
            }

            // Configure network data source with custom headers to bypass host protections
            val isYouTubeStream = decodedPath.contains("googlevideo.com") ||
                decodedPath.contains("youtube.com") || decodedPath.contains("youtu.be")

            val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(15000)

            // Build request headers
            val requestHeaders = mutableMapOf<String, String>()

            if (isYouTubeStream) {
                // YouTube/googlevideo streams require these headers to prevent 403
                requestHeaders["Origin"] = "https://www.youtube.com"
                requestHeaders["Referer"] = "https://www.youtube.com/"
                requestHeaders["Accept"] = "*/*"
                requestHeaders["Accept-Language"] = "en-US,en;q=0.9"
                requestHeaders["Sec-Fetch-Dest"] = "empty"
                requestHeaders["Sec-Fetch-Mode"] = "cors"
                requestHeaders["Sec-Fetch-Site"] = "cross-site"
                android.util.Log.d("VideoPlayer", "🎬 YouTube stream detected — injecting required headers")
            } else {
                android.util.Log.d("VideoPlayer", "🎬 VideoPlayerScreen: decodedPath = $decodedPath, referrerUrl = $referrerUrl")
                if (referrerUrl.isNotEmpty() && !isDirectVideoUrl(referrerUrl)) {
                    android.util.Log.d("VideoPlayer", "🎬 Setting Referer header to: $referrerUrl")
                    requestHeaders["Referer"] = referrerUrl
                } else {
                    android.util.Log.d("VideoPlayer", "🎬 Referer header NOT set. referrerUrl = $referrerUrl")
                }
            }

            val cookies = viewModel?.activeVideoCookies
            if (!cookies.isNullOrEmpty()) {
                requestHeaders["Cookie"] = cookies
                android.util.Log.d("VideoPlayer", "🎬 Injecting active session cookies to request headers")
            }

            if (requestHeaders.isNotEmpty()) {
                httpDataSourceFactory.setDefaultRequestProperties(requestHeaders)
            }

            val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpDataSourceFactory)
            val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(context)
                .setDataSourceFactory(dataSourceFactory)

            val mediaItemBuilder = MediaItem.Builder().setUri(uri)
            val urlLower = decodedPath.lowercase()

            // Detect MIME type: check URL query params first (googlevideo uses ?mime=video%2Fmp4)
            val mimeFromQuery = try {
                val parsedUri = android.net.Uri.parse(decodedPath)
                parsedUri.getQueryParameter("mime")?.let {
                    java.net.URLDecoder.decode(it, "UTF-8")
                }
            } catch (e: Exception) { null }

            when {
                mimeFromQuery != null -> {
                    android.util.Log.d("VideoPlayer", "🎬 Detected MIME from query param: $mimeFromQuery")
                    when {
                        mimeFromQuery.contains("mp4") -> mediaItemBuilder.setMimeType("video/mp4")
                        mimeFromQuery.contains("webm") -> mediaItemBuilder.setMimeType("video/webm")
                        mimeFromQuery.contains("audio/mp4") -> mediaItemBuilder.setMimeType("audio/mp4")
                        mimeFromQuery.contains("audio/webm") -> mediaItemBuilder.setMimeType("audio/webm")
                    }
                }
                urlLower.contains(".m3u8") || urlLower.contains("m3u8") || urlLower.contains("/hls/") ->
                    mediaItemBuilder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_M3U8)
                urlLower.contains(".mpd") || urlLower.contains("/dash/") ->
                    mediaItemBuilder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_MPD)
                urlLower.contains("index.php") || urlLower.contains(".php") -> {
                    if (!urlLower.contains(".mp4") && !urlLower.contains(".mkv") &&
                        !urlLower.contains(".webm") && !urlLower.contains(".avi") && !urlLower.contains(".mov")) {
                        android.util.Log.d("VideoPlayer", "🎬 PHP stream URL detected without progressive extension; setting mimeType to HLS (M3U8)")
                        mediaItemBuilder.setMimeType(androidx.media3.common.MimeTypes.APPLICATION_M3U8)
                    }
                }
            }



            val mediaItem = mediaItemBuilder.build()

            val player = ExoPlayer.Builder(context, CaptionRenderersFactory(context, captionTee))
                .setMediaSourceFactory(mediaSourceFactory)
                .build().apply {
                    setMediaItem(mediaItem)


                    // Media Handoff (Phase 5-7): restore live state from website <video>
                    val handoffPos = handoff?.currentPositionMs
                    val persistedPos = viewModel?.getVideoPosition(decodedPath)
                    val initialPos = handoffPos ?: persistedPos ?: 0L
                    if (initialPos > 0L) seekTo(initialPos)

                    // Restore playback speed from handoff or default
                    val speed = handoff?.playbackRate ?: 1.0f
                    if (speed != 1.0f) {
                        playbackParameters = PlaybackParameters(speed)
                    }

                    // Restore volume/mute from handoff
                    val handoffVolume = handoff?.volume
                    val handoffMuted = handoff?.muted
                    if (handoffVolume != null && handoffVolume in 0.0f..1.0f) {
                        volume = if (handoffMuted == true) 0f else handoffVolume
                    }

                    repeatMode = if (viewModel?.isPlayerLoopEnabled == true) {
                        Player.REPEAT_MODE_ONE
                    } else {
                        Player.REPEAT_MODE_OFF
                    }

                    val currentParams = trackSelectionParameters
                    val updatedParams = when (viewModel?.playerDefaultQuality) {
                        "360p" -> currentParams.buildUpon().setMaxVideoSize(640, 360).build()
                        "480p" -> currentParams.buildUpon().setMaxVideoSize(854, 480).build()
                        "720p" -> currentParams.buildUpon().setMaxVideoSize(1280, 720).build()
                        "1080p" -> currentParams.buildUpon().setMaxVideoSize(1920, 1080).build()
                        else -> currentParams
                    }
                    trackSelectionParameters = updatedParams

                    prepare()
                    // Media Handoff: respect website play/pause state over auto-play setting
                    playWhenReady = if (handoff != null) {
                        !handoff.isPaused
                    } else {
                        viewModel?.isPlayerAutoPlayEnabled ?: true
                    }

                    addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(playing: Boolean) {
                            isPlaying = playing
                        }
                        override fun onPlaybackStateChanged(state: Int) {
                            if (state == Player.STATE_READY) {
                                duration = this@apply.duration
                                updateTracksList(this@apply)
                            }
                        }
                        override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                            updateTracksList(this@apply)
                        }
                        override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                            android.util.Log.d("VideoPlayer", "🎬 onVideoSizeChanged: ${videoSize.width}x${videoSize.height}")
                        }
                        override fun onPositionDiscontinuity(
                            oldPosition: Player.PositionInfo,
                            newPosition: Player.PositionInfo,
                            reason: Int
                        ) {
                            // Any user seek discards stale caption text and restarts ASR
                            // around the new position — skipped audio is never transcribed.
                            if (reason == Player.DISCONTINUITY_REASON_SEEK) {
                                coroutineScope.launch { activeCaptionEngine?.reset() }
                            }
                        }
                        override fun onRenderedFirstFrame() {
                            // Strong signal that the video surface is actually rendering
                            // (i.e. NOT a black screen). Used to verify the surface bind fix.
                            android.util.Log.d("VideoPlayer", "🎬 onRenderedFirstFrame — first video frame rendered")
                        }
                        override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                            android.util.Log.e("VideoPlayer", "ExoPlayer playback error: ${error.message}", error)
                            viewModel?.cancelNativeHandoffAndResumeWeb("ExoPlayer error: ${error.message}")
                            coroutineScope.launch {
                                Toast.makeText(context, "${context.getString(R.string.video_player_playback_error)}: ${error.localizedMessage}", Toast.LENGTH_LONG).show()
                            }
                        }
                    })
                }

            exoPlayer = player
            exoPlayerInstance = player

            // BLACK-SCREEN FIX: bind the player to the PlayerView immediately and
            // deterministically. Previously the view only received the player via the
            // AndroidView `update` lambda reading `exoPlayerInstance`. Because that
            // state was assigned here (inside a DisposableEffect, after composition),
            // the view's `update` could run with a null player. The audio decoder runs
            // independently of the view, so audio played while the video surface never
            // bound → black screen. Attaching directly via the captured view reference
            // guarantees the surface is owned by ExoPlayer's own PlayerView output.
            playerViewRef?.player = player
            android.util.Log.d("VideoPlayer", "🎬 ExoPlayer created and bound to PlayerView (black-screen fix)")

            var wasPlayingBeforePause = false
            val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                if (event == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) {
                    if (viewModel?.isPlayerBackgroundPlaybackEnabled == false) {
                        wasPlayingBeforePause = player.playWhenReady
                        player.playWhenReady = false
                    }
                } else if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                    if (viewModel?.isPlayerBackgroundPlaybackEnabled == false && wasPlayingBeforePause) {
                        player.playWhenReady = true
                    }
                }
            }
            lifecycleObserver = observer
            lifecycleOwner.lifecycle.addObserver(observer)

        } catch (e: Exception) {
            android.util.Log.e("VideoPlayer", "Failed to initialize ExoPlayer: ${e.message}", e)
            viewModel?.cancelNativeHandoffAndResumeWeb()
            coroutineScope.launch {
                Toast.makeText(context, "Unable to play in Omni Player: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                kotlinx.coroutines.delay(300)
                onNavigateBack()
            }
        }

        onDispose {
            try {
                lifecycleObserver?.let { lifecycleOwner.lifecycle.removeObserver(it) }
                exoPlayer?.let { player ->
                    val finalPos = player.currentPosition
                    val finalPlaying = player.isPlaying
                    val finalSpeed = player.playbackParameters.speed
                    val finalVolume = player.volume
                    val finalMuted = finalVolume == 0f
                    viewModel?.saveVideoPosition(decodedPath, finalPos)
                    viewModel?.returnFromNativePlayer(
                        positionMs = finalPos,
                        isPlaying = finalPlaying,
                        playbackRate = finalSpeed,
                        volume = finalVolume,
                        muted = finalMuted
                    )
                    player.stop()
                    player.release()
                }
                exoPlayerInstance = null
            } catch (e: Exception) {
                android.util.Log.w("VideoPlayer", "Error during ExoPlayer dispose: ${e.message}")
            }
        }
    }

    // Progress updates tracking — runs continuously regardless of play state
    // so the slider stays accurate after seeks and during buffering
    LaunchedEffect(Unit) {
        while (true) {
            if (!isSeeking) {
                exoPlayerInstance?.let { player ->
                    playbackPosition = player.currentPosition
                    viewModel?.updateActiveVideoSession(
                        positionMs = player.currentPosition,
                        isPlaying = player.isPlaying,
                        playbackRate = player.playbackParameters.speed,
                        volume = player.volume,
                        muted = player.volume == 0f
                    )
                    if (isPlaying) {
                        viewModel?.saveVideoPosition(decodedPath, player.currentPosition)
                    }
                }
            }
            delay(200)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (youtubeVideoId != null) {
            // Capture the WebView reference so onRelease can properly destroy it,
            // preventing the ~50–150MB Chromium renderer from leaking on close.
            var youtubeWebView by remember { mutableStateOf<android.webkit.WebView?>(null) }
            var customView by remember { mutableStateOf<android.view.View?>(null) }
            var customViewCallback by remember { mutableStateOf<android.webkit.WebChromeClient.CustomViewCallback?>(null) }

            DisposableEffect(youtubeVideoId) {
                onDispose {
                    youtubeWebView?.apply {
                        try {
                            stopLoading()
                            loadUrl("about:blank")
                            removeAllViews()
                            destroy()
                        } catch (_: Exception) {}
                    }
                    youtubeWebView = null
                }
            }

            BackHandler(enabled = customView != null) {
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            }

            if (customView != null) {
                AndroidView(
                    factory = { customView!! },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                AndroidView(
                    factory = { ctx ->
                        android.webkit.WebView(ctx).also { youtubeWebView = it }.apply {
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                allowFileAccess = false
                                mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            }
                            webViewClient = android.webkit.WebViewClient()
                            webChromeClient = object : android.webkit.WebChromeClient() {
                                override fun onShowCustomView(view: android.view.View?, callback: CustomViewCallback?) {
                                    customView = view
                                    customViewCallback = callback
                                    activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                }

                                override fun onHideCustomView() {
                                    customView = null
                                    customViewCallback?.onCustomViewHidden()
                                    customViewCallback = null
                                    activity?.requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                }
                            }
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            // Use loadDataWithBaseURL so the iframe has a YouTube origin,
                            // which is required for autoplay and the IFrame Player API to work.
                            val embedHtml = """
                                <!DOCTYPE html>
                                <html>
                                <head>
                                <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
                                <style>
                                * { margin:0; padding:0; box-sizing:border-box; background:#000; }
                                html, body { width:100%; height:100%; overflow:hidden; }
                                iframe { width:100%; height:100%; border:none; display:block; }
                                </style>
                                </head>
                                <body>
                                <iframe
                                    src="https://www.youtube.com/embed/$youtubeVideoId?autoplay=1&rel=0&showinfo=0&controls=1&playsinline=1&enablejsapi=1"
                                    allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                                    allowfullscreen>
                                </iframe>
                                </body>
                                </html>
                            """.trimIndent()
                            loadDataWithBaseURL(
                                "https://www.youtube.com",
                                embedHtml,
                                "text/html",
                                "UTF-8",
                                null
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            // ExoPlayer Canvas Surface
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        // Prevent the native PlayerView from intercepting touch events;
                        // all touch handling is done by the Compose overlay layer.
                        isClickable = false
                        isFocusable = false
                        // Transparent shutter background prevents black screen masking before/during video frame rendering
                        setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        resizeMode = aspectMode.toResizeMode()
                        // Capture the view reference so the player-init effect above can
                        // bind the player deterministically (prevents black screen).
                        player = exoPlayerInstance
                        playerViewRef = this
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { playerView ->
                    // Keep the binding in sync; guarded so we don't thrash the surface.
                    if (playerView.player !== exoPlayerInstance) {
                        playerView.player = exoPlayerInstance
                    }
                    playerView.resizeMode = aspectMode.toResizeMode()
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // ── Offline live captions overlay (hidden in PiP) ────────────────────
        if (captionActive && viewModel?.isInPictureInPictureMode != true) {
            val engine = activeCaptionEngine
            if (engine != null) {
                val captionLines by engine.lines.collectAsState()
                val captionPartial by engine.partial.collectAsState()
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(bottom = 110.dp, start = 24.dp, end = 24.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        captionLines.takeLast(2).forEach { line ->
                            Surface(
                                color = Color.Black.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    line.text,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                        if (captionPartial.isNotBlank()) {
                            Surface(
                                color = Color.Black.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    captionPartial,
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 15.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // ── Offline caption model dialog (download on demand) ────────────────
        if (showCaptionModelDialog) {
            val desc = asrDescriptor
            AlertDialog(
                onDismissRequest = { showCaptionModelDialog = false },
                containerColor = if (viewModel?.isAmoledMode == true) Color(0xFF000000) else MaterialTheme.colorScheme.surface,
                title = {
                    Text(
                        text = "Offline captions model required",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (desc != null) {
                            Text(
                                text = "${desc.name} — downloaded once, verified, and stored only on this device. No audio is uploaded.",
                                fontSize = 13.sp,
                                color = if (viewModel?.isDarkThemeEnabled != false) Color.White else Color(0xFF1C1C1E)
                            )
                            val st = captionRepoStates[desc.id] ?: ModelState(descriptor = desc)
                            when {
                                st.status == ModelInstallState.DOWNLOADING || st.status == ModelInstallState.VERIFYING -> {
                                    Text(
                                        text = "Downloading… ${st.progress.bytesDownloaded} / ${st.progress.totalBytes}",
                                        fontSize = 13.sp,
                                        color = if (viewModel?.isDarkThemeEnabled != false) Color(0xFF8E8E93) else Color(0xFF8E8E93)
                                    )
                                    LinearProgressIndicator(
                                        progress = { if (st.progress.isIndeterminate) 0.4f else st.progress.fraction },
                                        modifier = Modifier.fillMaxWidth().height(6.dp)
                                    )
                                }
                                st.status == ModelInstallState.FAILED -> {
                                    Text(
                                        text = st.errorMessage ?: "Download failed",
                                        fontSize = 13.sp,
                                        color = Color(0xFFFF3B30)
                                    )
                                }
                            }
                        } else {
                            Text("No caption model is available in the catalog.", fontSize = 13.sp)
                        }
                    }
                },
                confirmButton = {
                    if (desc != null) {
                        val st = captionRepoStates[desc.id] ?: ModelState(descriptor = desc)
                        val installing = st.status == ModelInstallState.DOWNLOADING || st.status == ModelInstallState.VERIFYING
                        if (!installing && !captionPlatform.repository.isInstalled(desc)) {
                            TextButton(onClick = { coroutineScope.launch { captionPlatform.repository.install(desc) } }) {
                                Text("Download", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCaptionModelDialog = false }) { Text("Cancel") }
                }
            )

            // Auto-start captions the moment the install completes.
            LaunchedEffect(desc?.id, captionRepoStates[desc?.id]?.status) {
                if (desc != null && captionRepoStates[desc.id]?.status == ModelInstallState.INSTALLED) {
                    showCaptionModelDialog = false
                    startOfflineCaptions()
                }
            }
        }

        // All UI overlays are hidden in PiP mode — only raw video is shown in the floating window
        val isPiP = viewModel?.isInPictureInPictureMode == true
        if (!isPiP) {
            if (youtubeVideoId != null) {
                if (!isLandscape) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .safeDrawingPadding()
                            .padding(12.dp)
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.Black.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            } else {

        // Full-screen Gesture Interceptor: Handles horizontal video scrubbing, vertical brightness & volume drag, single tap & double tap
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(viewModel?.isPlayerBrightnessGestureEnabled, viewModel?.isPlayerVolumeGestureEnabled, duration) {
                    val brightnessEnabled = viewModel?.isPlayerBrightnessGestureEnabled != false
                    val volumeEnabled = viewModel?.isPlayerVolumeGestureEnabled != false

                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val startPos = down.position
                        val isLeftHalf = startPos.x < (size.width / 2f)
                        val containerWidth = size.width.toFloat().coerceAtLeast(1f)

                        var totalDx = 0f
                        var totalDy = 0f
                        var gestureMode = 0 // 0: Undetermined, 1: Horizontal Scrubbing, 2: Vertical Brightness, 3: Vertical Volume

                        val initialPosition = exoPlayerInstance?.currentPosition ?: playbackPosition
                        var wasPlayingBeforeScrub = isPlaying

                        do {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            val dx = change.position.x - change.previousPosition.x
                            val dy = change.position.y - change.previousPosition.y

                            totalDx += dx
                            totalDy += dy

                            if (gestureMode == 0) {
                                if (kotlin.math.abs(totalDx) > 8f && kotlin.math.abs(totalDx) > kotlin.math.abs(totalDy)) {
                                    if (duration > 0) {
                                        gestureMode = 1
                                        wasPlayingBeforeScrub = isPlaying
                                        exoPlayerInstance?.playWhenReady = false
                                        isSeeking = true
                                    }
                                } else if (kotlin.math.abs(totalDy) > 8f && kotlin.math.abs(totalDy) > kotlin.math.abs(totalDx)) {
                                    if (isLeftHalf && brightnessEnabled) {
                                        gestureMode = 2
                                    } else if (!isLeftHalf && volumeEnabled) {
                                        gestureMode = 3
                                    }
                                }
                            }

                            when (gestureMode) {
                                1 -> {
                                    // Horizontal Video Scrubbing
                                    val sensitivity = duration.coerceAtMost(180_000L).coerceAtLeast(60_000L)
                                    val deltaMs = ((totalDx / containerWidth) * sensitivity).toLong()
                                    val targetPos = (initialPosition + deltaMs).coerceIn(0L, duration)

                                    seekTargetPosition = targetPos
                                    playbackPosition = targetPos
                                    exoPlayerInstance?.seekTo(targetPos)

                                    val deltaSec = (targetPos - initialPosition) / 1000L
                                    val deltaSign = if (deltaSec >= 0) "+" else "-"
                                    val absDeltaSec = kotlin.math.abs(deltaSec)
                                    val deltaFormatted = "$deltaSign${formatDuration(absDeltaSec * 1000L)}"
                                    val icon = if (deltaSec >= 0) "⏩" else "⏪"

                                    gestureIndicatorText = "$icon ${formatDuration(targetPos)} / ${formatDuration(duration)} ($deltaFormatted)"
                                    showGestureIndicator = true
                                    change.consume()
                                }
                                2 -> {
                                    // Vertical Brightness Adjustment
                                    brightness = (brightness - dy / 600f).coerceIn(0.01f, 1f)
                                    setWindowBrightness(brightness)
                                    gestureIndicatorText = "🔆 ${(brightness * 100).toInt()}%"
                                    showGestureIndicator = true
                                    change.consume()
                                }
                                3 -> {
                                    // Vertical Volume Adjustment
                                    val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                    volume = (volume - dy / 600f).coerceIn(0f, 1f)
                                    audioManager.setStreamVolume(
                                        AudioManager.STREAM_MUSIC,
                                        (volume * maxVol).toInt(),
                                        0
                                    )
                                    gestureIndicatorText = "🔊 ${(volume * 100).toInt()}%"
                                    showGestureIndicator = true
                                    change.consume()
                                }
                            }
                        } while (event.changes.any { it.pressed })

                        if (gestureMode == 1) {
                            // Finish scrubbing gesture
                            exoPlayerInstance?.let { player ->
                                player.seekTo(seekTargetPosition)
                                if (wasPlayingBeforeScrub) {
                                    player.playWhenReady = true
                                }
                            }
                            isSeeking = false
                            gestureIndicatorJob?.cancel()
                            gestureIndicatorJob = coroutineScope.launch {
                                delay(500)
                                showGestureIndicator = false
                            }
                        } else if (gestureMode == 2 || gestureMode == 3) {
                            showGestureIndicator = false
                        } else if (gestureMode == 0) {
                            // Tap handling (single tap toggles controls, double tap jumps ±10s)
                            val currentTime = System.currentTimeMillis()
                            if (isLeftHalf) {
                                if (currentTime - lastLeftTapTime < 300) {
                                    leftTapJob?.cancel()
                                    exoPlayerInstance?.let { player ->
                                        val newPos = (player.currentPosition - 10_000).coerceAtLeast(0L)
                                        player.seekTo(newPos)
                                        gestureIndicatorText = "⏪ -10s"
                                        showGestureIndicator = true
                                        gestureIndicatorJob?.cancel()
                                        gestureIndicatorJob = coroutineScope.launch {
                                            delay(1000)
                                            showGestureIndicator = false
                                        }
                                    }
                                } else {
                                    leftTapJob?.cancel()
                                    leftTapJob = coroutineScope.launch {
                                        delay(300)
                                        showControls = !showControls
                                    }
                                }
                                lastLeftTapTime = currentTime
                            } else {
                                if (currentTime - lastRightTapTime < 300) {
                                    rightTapJob?.cancel()
                                    exoPlayerInstance?.let { player ->
                                        val newPos = (player.currentPosition + 10_000).coerceAtMost(duration)
                                        player.seekTo(newPos)
                                        gestureIndicatorText = "⏩ +10s"
                                        showGestureIndicator = true
                                        gestureIndicatorJob?.cancel()
                                        gestureIndicatorJob = coroutineScope.launch {
                                            delay(1000)
                                            showGestureIndicator = false
                                        }
                                    }
                                } else {
                                    rightTapJob?.cancel()
                                    rightTapJob = coroutineScope.launch {
                                        delay(300)
                                        showControls = !showControls
                                    }
                                }
                                lastRightTapTime = currentTime
                            }
                        }
                    }
                }
        )


        // Swipe / Drag HUD indicator popup
        AnimatedVisibility(
            visible = showGestureIndicator,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Surface(
                color = Color.Black.copy(alpha = 0.7f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.2f))
            ) {
                Text(
                    text = gestureIndicatorText,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical =10.dp)
                )
            }
        }

        // Elegant Media Playback Overlays
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // 1. Transparent scrim background that is clickable to dismiss controls
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = null
                        ) {
                            showControls = false
                        }
                )

                // 2. Interactive Controls Layer (Header, Middle, Bottom)
                // This is a sibling to the scrim Box and sits on top. Since this Box itself has no
                // clickable modifier, click events on empty spaces pass through to the scrim Box beneath.
                // Buttons and sliders consume clicks directly, preventing any interference.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding()
                ) {
                    // Header (Back + Name + Controls)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopStart)
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color.Black.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        val displayName = remember(decodedPath, videoTitle) {
                            if (videoTitle.isNotEmpty()) {
                                videoTitle
                            } else if (decodedPath.startsWith("http://") || decodedPath.startsWith("https://")) {
                                Uri.parse(decodedPath).lastPathSegment ?: "Online Stream"
                            } else {
                                java.io.File(decodedPath).name
                            }
                        }
                        Text(
                            text = displayName,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        // Screen orientation toggle (Enter / Exit Fullscreen)
                        // isLandscape is captured from the top-level scope of VideoPlayerScreen
                        IconButton(
                            onClick = {
                                activity?.let { act ->
                                    // Dismiss controls immediately so the rotation looks clean
                                    showControls = false
                                    // SENSOR_LANDSCAPE respects which way the user is holding the
                                    // device (avoids locking to the wrong landscape direction)
                                    act.requestedOrientation = if (isLandscape) {
                                        android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                    } else {
                                        android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                    }
                                    // After the rotation animation completes, re-show controls
                                    // briefly so the user sees they are in the new orientation
                                    coroutineScope.launch {
                                        delay(700)
                                        showControls = true
                                    }
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (isLandscape) accentColor.copy(alpha = 0.8f) else Color.Black.copy(alpha = 0.6f)
                            ),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = if (isLandscape) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                contentDescription = if (isLandscape) "Exit Fullscreen" else "Enter Fullscreen",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // CC (Closed Captions) toggle button
                        val isSubtitlesDisabled = exoPlayerInstance?.trackSelectionParameters?.disabledTrackTypes?.contains(androidx.media3.common.C.TRACK_TYPE_TEXT) == true
                        val isSubtitlesActive = !isSubtitlesDisabled && subtitleTracks.any { it.isSelected }

                        IconButton(
                            onClick = {
                                exoPlayerInstance?.let { player ->
                                    if (isSubtitlesActive) {
                                        disableSubtitles(player)
                                        Toast.makeText(context, "Subtitles Disabled", Toast.LENGTH_SHORT).show()
                                    } else if (subtitleTracks.isNotEmpty()) {
                                        selectSubtitleTrack(player, subtitleTracks.first())
                                        Toast.makeText(context, "Subtitles Enabled: ${subtitleTracks.first().label}", Toast.LENGTH_SHORT).show()
                                    } else {
                                        // No embedded subtitles: offer on-device generated captions.
                                        showSettingsDialog = true
                                        selectedSettingsTab = "Subtitles (CC)"
                                        startOfflineCaptions()
                                    }
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (isSubtitlesActive) accentColor.copy(alpha = 0.8f) else Color.Black.copy(alpha = 0.6f)
                            ),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ClosedCaption,
                                contentDescription = "Toggle Subtitles (CC)",
                                tint = if (isSubtitlesActive) Color.White else Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Aspect Ratio (Fit / Fill / Stretch) Button
                        IconButton(
                            onClick = {
                                val nextMode = when (aspectMode) {
                                    AspectMode.FIT -> AspectMode.FILL
                                    AspectMode.FILL -> AspectMode.STRETCH
                                    AspectMode.STRETCH -> AspectMode.FIT
                                }
                                aspectMode = nextMode
                                val newLabel = when (nextMode) {
                                    AspectMode.FIT -> aspectFitText
                                    AspectMode.FILL -> aspectFillText
                                    AspectMode.STRETCH -> aspectStretchText
                                }
                                gestureIndicatorText = newLabel
                                showGestureIndicator = true
                                coroutineScope.launch {
                                    delay(1500)
                                    showGestureIndicator = false
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (aspectMode != AspectMode.FIT) accentColor.copy(alpha = 0.8f) else Color.Black.copy(alpha = 0.6f)
                            ),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AspectRatio,
                                contentDescription = aspectLabel,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Playback Settings button
                        IconButton(
                            onClick = {
                                exoPlayerInstance?.let { updateTracksList(it) }
                                showSettingsDialog = true
                            },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color.Black.copy(alpha = 0.6f)),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Settings,
                                contentDescription = "Playback Settings",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        
                        // PiP Trigger Button
                        Button(
                            onClick = {
                                if (activity != null && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                    val params = PictureInPictureParams.Builder()
                                        .setAspectRatio(Rational(16, 9))
                                        .build()
                                    activity.enterPictureInPictureMode(params)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text(stringResource(R.string.pip_mode), color = Color.White, fontSize = 14.sp)
                        }

                        if (isOnline && downloadEngine != null && currentJob == null) {
                            val sourceHdLabel = stringResource(R.string.download_quality_source_hd_original)
                            val sourceStreamLabel = stringResource(R.string.download_quality_source_stream)
                            val extractAudioLabel = stringResource(R.string.download_quality_extract_audio)
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        isFetchingQualities = true
                                        val streamDuration = if (duration > 0L) duration else (exoPlayerInstance?.duration?.takeIf { it > 0 } ?: 0L)
                                        val streamBitrate = exoPlayerInstance?.videoFormat?.bitrate ?: -1
                                        val parsed = fetchVideoQualities(
                                            streamUrl = decodedPath,
                                            cookies = viewModel?.activeVideoCookies,
                                            sourceHdLabel = sourceHdLabel,
                                            sourceStreamLabel = sourceStreamLabel,
                                            extractAudioLabel = extractAudioLabel,
                                            durationMs = streamDuration,
                                            activeBitrate = streamBitrate,
                                            referrer = if (referrerUrl.isNotEmpty()) referrerUrl else null
                                        )
                                        isFetchingQualities = false
                                        
                                        if (decodedPath.contains(".m3u8") && parsed.count { !it.isAudioOnly } <= 1) {
                                            Toast.makeText(context, context.getString(R.string.video_player_m3u8_fallback), Toast.LENGTH_SHORT).show()
                                        }
                                        
                                        qualityOptions = parsed
                                        showQualitySelector = true
                                    }
                                },
                                colors = IconButtonDefaults.iconButtonColors(containerColor = Color.Black.copy(alpha = 0.6f)),
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Download,
                                    contentDescription = stringResource(R.string.downloads_title),
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    // Middle: Play/Pause/Rewind/Forward Controls
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        // Rewind 10s
                        IconButton(
                            onClick = {
                                exoPlayerInstance?.let { it.seekTo((it.currentPosition - 10_000).coerceAtLeast(0L)) }
                            },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color.Black.copy(alpha = 0.5f)),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FastRewind,
                                contentDescription = "Rewind 10s",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Play/Pause Toggle
                        IconButton(
                            onClick = {
                                exoPlayerInstance?.let {
                                    if (isPlaying) it.pause() else it.play()
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = accentColor),
                            modifier = Modifier.size(64.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Forward 10s
                        IconButton(
                            onClick = {
                                exoPlayerInstance?.let { it.seekTo((it.currentPosition + 10_000).coerceAtMost(duration)) }
                            },
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color.Black.copy(alpha = 0.5f)),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FastForward,
                                contentDescription = "Forward 10s",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // Bottom Seek Slider
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(formatDuration(playbackPosition), color = Color.White, fontSize = 12.sp)
                            Text(formatDuration(duration), color = Color.White, fontSize = 12.sp)
                        }
                        Slider(
                            value = if (duration > 0) playbackPosition.toFloat() / duration else 0f,
                            onValueChange = { percent ->
                                if (!isSliderScrubbing) {
                                    isSliderScrubbing = true
                                    sliderStartPos = playbackPosition
                                    exoPlayerInstance?.playWhenReady = false
                                }
                                isSeeking = true
                                seekTargetPosition = (percent * duration).toLong().coerceIn(0L, duration)
                                playbackPosition = seekTargetPosition
                                exoPlayerInstance?.seekTo(seekTargetPosition)

                                val deltaSec = (seekTargetPosition - sliderStartPos) / 1000L
                                val deltaSign = if (deltaSec >= 0) "+" else "-"
                                val absDeltaSec = kotlin.math.abs(deltaSec)
                                val deltaFormatted = "$deltaSign${formatDuration(absDeltaSec * 1000L)}"
                                val icon = if (deltaSec >= 0) "⏩" else "⏪"

                                gestureIndicatorText = "$icon ${formatDuration(seekTargetPosition)} / ${formatDuration(duration)} ($deltaFormatted)"
                                showGestureIndicator = true
                            },
                            onValueChangeFinished = {
                                exoPlayerInstance?.let { player ->
                                    player.seekTo(seekTargetPosition)
                                    player.playWhenReady = true
                                }
                                isSeeking = false
                                isSliderScrubbing = false
                                gestureIndicatorJob?.cancel()
                                gestureIndicatorJob = coroutineScope.launch {
                                    delay(500)
                                    showGestureIndicator = false
                                }
                            },
                            colors = SliderDefaults.colors(
                                activeTrackColor = accentColor,
                                inactiveTrackColor = Color.White.copy(alpha = 0.3f),
                                thumbColor = accentColor
                            )
                        )
                    }
                }
            }
        }

        // 1. Quality fetching loading spinner
        if (isFetchingQualities) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = Color(0xFF0D1620),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(0.5.dp, Color(0xFF16222F)),
                    modifier = Modifier.width(280.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(color = accentColor)
                        Text(
                            text = "Analyzing Stream Qualities...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Playback Settings Dialog (Speed, Audio Dub, Subtitles CC)
        if (showSettingsDialog) {
            val isDark = viewModel?.isDarkThemeEnabled != false
            val dialogBg = if (isDark) Color(0xFF141416) else Color(0xFFFFFFFF)
            val dialogBorder = if (isDark) Color(0xFF2C2C2E) else Color(0xFFE5E5EA)
            val textPrimary = if (isDark) Color.White else Color(0xFF1C1C1E)
            val textSecondary = if (isDark) Color(0xFF8E8E93) else Color(0xFF8E8E93)
            val dividerColor = if (isDark) Color(0xFF2C2C2E) else Color(0xFFF1F3F4)
            val itemSelectedBg = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)

            androidx.compose.ui.window.Dialog(
                onDismissRequest = { showSettingsDialog = false },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
            ) {
                // Width fraction kept for phones; on medium+ windows the dialog
                // is capped so it never becomes a full-screen slab.
                val settingsDialogMaxWidth = com.rebelroot.omni.ui.adaptive.rememberAdaptiveUiMetrics().sheetMaxWidth
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(if (isLandscape) 0.65f else 0.9f)
                        .widthIn(max = settingsDialogMaxWidth)
                        .height(if (isLandscape) 320.dp else 400.dp)
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    color = dialogBg,
                    border = BorderStroke(1.dp, dialogBorder),
                    shadowElevation = 24.dp
                ) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        // Left Sidebar: Categories
                        Column(
                            modifier = Modifier
                                .weight(0.35f)
                                .fillMaxHeight()
                                .background(if (isDark) Color(0xFF1C1C1E) else Color(0xFFF2F2F7))
                                .padding(vertical = 12.dp)
                        ) {
                            val tabs = listOf("Speed", "Quality", "Audio (Dub)", "Subtitles (CC)", "Servers", "Media")
                            tabs.forEach { tab ->
                                val isSelected = selectedSettingsTab == tab
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedSettingsTab = tab }
                                        .background(if (isSelected) itemSelectedBg else Color.Transparent)
                                        .padding(horizontal = 16.dp, vertical = 14.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    Text(
                                        text = tab,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }

                        // Right Content Panel
                        Box(
                            modifier = Modifier
                                .weight(0.65f)
                                .fillMaxHeight()
                                .padding(16.dp)
                        ) {
                            when (selectedSettingsTab) {
                                "Speed" -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("Playback Speed", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))

                                        val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 3.0f, 5.0f)
                                        speeds.forEach { speed ->
                                            val isSelected = currentSpeed == speed
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .clickable {
                                                        currentSpeed = speed
                                                        exoPlayerInstance?.setPlaybackSpeed(speed)
                                                        showSettingsDialog = false
                                                    }
                                                    .background(if (isSelected) itemSelectedBg else Color.Transparent)
                                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = if (speed == 1.0f) "Normal (1.0x)" else "${speed}x",
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                                    fontSize = 14.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                )
                                                if (isSelected) {
                                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                                "Quality" -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("Video Quality", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))

                                        val isAutoSelected = videoTracks.none { it.isSelected }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable {
                                                    exoPlayerInstance?.let { player ->
                                                        selectAutoVideo(player)
                                                    }
                                                }
                                                .background(if (isAutoSelected) itemSelectedBg else Color.Transparent)
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Auto (Adaptive)",
                                                color = if (isAutoSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                                fontSize = 14.sp,
                                                fontWeight = if (isAutoSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                            if (isAutoSelected) {
                                                Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        HorizontalDivider(color = dividerColor, modifier = Modifier.padding(vertical = 4.dp))

                                        if (videoTracks.isEmpty()) {
                                            Text(stringResource(R.string.download_quality_auto_source_only), color = textSecondary, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                                        } else {
                                            videoTracks.forEach { track ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            exoPlayerInstance?.let { player ->
                                                                selectVideoTrack(player, track)
                                                            }
                                                        }
                                                        .background(if (track.isSelected) itemSelectedBg else Color.Transparent)
                                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = track.label,
                                                        color = if (track.isSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                                        fontSize = 14.sp,
                                                        fontWeight = if (track.isSelected) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    if (track.isSelected) {
                                                        Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                "Audio (Dub)" -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("Audio Channels / Tracks", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))

                                        if (audioTracks.isEmpty()) {
                                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text("No audio tracks found", color = textSecondary, fontSize = 13.sp)
                                            }
                                        } else {
                                            audioTracks.forEach { track ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            exoPlayerInstance?.let { player ->
                                                                selectAudioTrack(player, track)
                                                            }
                                                        }
                                                        .background(if (track.isSelected) itemSelectedBg else Color.Transparent)
                                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = track.label,
                                                        color = if (track.isSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                                        fontSize = 14.sp,
                                                        fontWeight = if (track.isSelected) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    if (track.isSelected) {
                                                        Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                "Subtitles (CC)" -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("Subtitles / Captions", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))

                                        // Off option
                                        val isSubtitlesDisabled = exoPlayerInstance?.trackSelectionParameters?.disabledTrackTypes?.contains(androidx.media3.common.C.TRACK_TYPE_TEXT) == true
                                        val noSubtitleSelected = isSubtitlesDisabled || subtitleTracks.none { it.isSelected }

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable {
                                                    exoPlayerInstance?.let { player ->
                                                        disableSubtitles(player)
                                                    }
                                                }
                                                .background(if (noSubtitleSelected) itemSelectedBg else Color.Transparent)
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Off / Disabled",
                                                color = if (noSubtitleSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                                fontSize = 14.sp,
                                                fontWeight = if (noSubtitleSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                            if (noSubtitleSelected) {
                                                Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        HorizontalDivider(color = dividerColor, modifier = Modifier.padding(vertical = 4.dp))

                                        if (subtitleTracks.isEmpty()) {
                                            Text("No subtitles found", color = textSecondary, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                                        } else {
                                            subtitleTracks.forEach { track ->
                                                val isSelected = track.isSelected && !isSubtitlesDisabled
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            exoPlayerInstance?.let { player ->
                                                                selectSubtitleTrack(player, track)
                                                            }
                                                        }
                                                        .background(if (isSelected) itemSelectedBg else Color.Transparent)
                                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = track.label,
                                                        color = if (isSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                                        fontSize = 14.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    if (isSelected) {
                                                        Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }

                                        HorizontalDivider(color = dividerColor, modifier = Modifier.padding(vertical = 8.dp))

                                        // ── Offline generated captions (on-device ASR) ──
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Generate captions (offline)", color = textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                                Text(
                                                    if (captionActive) "Live on-device captions active — no upload"
                                                    else "Speech-to-text on this device, from a downloaded model",
                                                    color = textSecondary, fontSize = 11.sp
                                                )
                                            }
                                            if (captionActive) {
                                                OutlinedButton(onClick = { stopOfflineCaptions() }, shape = RoundedCornerShape(12.dp)) {
                                                    Text("Stop", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                            } else {
                                                Button(
                                                    onClick = { startOfflineCaptions() },
                                                    shape = RoundedCornerShape(12.dp),
                                                    enabled = !captionBusy
                                                ) {
                                                    Text(if (captionBusy) "Starting…" else "Generate", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }

                                        HorizontalDivider(color = dividerColor)

                                        Text("Live Caption (Speech-to-Text)", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 4.dp))
                                        Text("Automatically generate subtitles for any media playing on your device using Android system captions.", color = textSecondary, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))

                                        Button(
                                            onClick = {
                                                val captionIntents = listOf(
                                                    Intent("android.settings.LIVE_CAPTION_SETTINGS"),
                                                    Intent("com.google.android.settings.action.LIVE_CAPTION"),
                                                    Intent(Settings.ACTION_CAPTIONING_SETTINGS),
                                                    Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
                                                    Intent(Settings.ACTION_SETTINGS)
                                                )
                                                var launched = false
                                                for (intent in captionIntents) {
                                                    try {
                                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                        context.startActivity(intent)
                                                        launched = true
                                                        break
                                                    } catch (e: Exception) {
                                                        // Try next intent
                                                    }
                                                }
                                                if (!launched) {
                                                    Toast.makeText(context, "Cannot open system caption settings", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(Icons.Rounded.ClosedCaption, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                                Text("Open Caption Settings", color = Color.White, fontSize = 13.sp)
                                            }
                                        }
                                    }
                                }
                                "Media" -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text("Media Tools", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 4.dp))
                                        val vm = viewModel
                                        if (vm != null) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text("Media Sniffer / Fetcher", color = textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                                    Text("Detect web page videos and show the sniffer banner", color = textSecondary, fontSize = 11.sp)
                                                }
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(onClick = { showSnifferSubDialog = true }) {
                                                        Icon(
                                                            Icons.Rounded.Tune,
                                                            contentDescription = "Sniffer Settings",
                                                            tint = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                    }
                                                    Switch(
                                                        checked = vm.isMediaGrabberEnabled,
                                                        onCheckedChange = { vm.toggleMediaGrabber(context) }
                                                    )
                                                }
                                            }
                                            Text(
                                                text = "Tap the settings symbol to open the full sniffer settings.",
                                                color = textSecondary,
                                                fontSize = 11.sp
                                            )
                                        } else {
                                            Text("Browser settings unavailable", color = textSecondary, fontSize = 12.sp)
                                        }
                                    }
                                }
                                "Servers" -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text("Switch Server / Source", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))

                                        val detectedMedia = viewModel?.mediaInterceptor?.detectedMedia?.collectAsState()?.value ?: emptyList()
                                        if (detectedMedia.isEmpty()) {
                                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text("No alternative servers detected", color = textSecondary, fontSize = 13.sp)
                                            }
                                        } else {
                                            detectedMedia.forEachIndexed { idx, media ->
                                                val isSelected = media.url == decodedPath
                                                val host = remember(media.url) {
                                                    try { Uri.parse(media.url).host ?: "Direct Stream" } catch (e: Exception) { "Direct Stream" }
                                                }
                                                val typeLabel = when (media.type) {
                                                    com.rebelroot.omni.media.MediaInterceptor.MediaType.HLS -> "HLS Adaptive"
                                                    com.rebelroot.omni.media.MediaInterceptor.MediaType.DASH -> "DASH Stream"
                                                    com.rebelroot.omni.media.MediaInterceptor.MediaType.WEBM -> "WEBM Video"
                                                    else -> "MP4 Video"
                                                }

                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .clickable {
                                                            decodedPath = media.url
                                                            showSettingsDialog = false
                                                        }
                                                        .background(if (isSelected) itemSelectedBg else Color.Transparent)
                                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = stringResource(R.string.download_server_label, idx + 1) + " (${translateQualityLabel(media.quality)})",
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else textPrimary,
                                                            fontSize = 14.sp,
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                                        )
                                                        Text(
                                                            text = "$typeLabel • $host",
                                                            color = textSecondary,
                                                            fontSize = 11.sp
                                                        )
                                                    }
                                                    if (isSelected) {
                                                        Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sniffer settings sub-dialog, opened from the Media tab's settings symbol.
        if (showSnifferSubDialog && viewModel != null) {
            com.rebelroot.omni.browser.MediaSnifferSettingsDialog(
                viewModel = viewModel!!,
                onDismissRequest = { showSnifferSubDialog = false }
            )
        }


        // 2. Beautiful quality selector alert dialog
        if (showQualitySelector && downloadEngine != null) {
            val suggestedName = remember(decodedPath, videoTitle) {
                if (videoTitle.isNotEmpty()) {
                    videoTitle
                } else {
                    val lastSeg = Uri.parse(decodedPath).lastPathSegment
                    if (!lastSeg.isNullOrBlank() && lastSeg.contains(".")) {
                        lastSeg.substringBeforeLast(".")
                    } else {
                        "Video_${System.currentTimeMillis()}"
                    }
                }
            }

            AlertDialog(
                onDismissRequest = { showQualitySelector = false },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(accentColor.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Download,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = stringResource(R.string.video_player_select_quality),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                text = {
                    val scrollState = rememberScrollState()
                    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
                    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
                    
                    val qualityItemContent = @Composable { option: VideoQualityOption ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showQualitySelector = false
                                    val mediaType = when {
                                        option.isAudioOnly -> MediaInterceptor.MediaType.AUDIO
                                        option.url.contains(".m3u8") -> MediaInterceptor.MediaType.HLS
                                        option.url.contains(".mpd") -> MediaInterceptor.MediaType.DASH
                                        else -> MediaInterceptor.MediaType.MP4
                                    }
                                    coroutineScope.launch {
                                        downloadEngine.startDownload(
                                            url = option.url,
                                            suggestedName = "${suggestedName}_${option.label}",
                                            type = mediaType,
                                            saveToLocker = downloadToLocker,
                                            referrerUrl = if (referrerUrl.isNotEmpty()) referrerUrl else null,
                                            cookies = viewModel?.activeVideoCookies
                                        )
                                        val toastMsg = if (downloadToLocker) context.getString(R.string.video_player_queued_locker) else context.getString(R.string.video_player_queued_download, option.label)
                                        Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
                                    }
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF16222F),
                            border = BorderStroke(0.5.dp, Color(0xFF23374A))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = if (option.isAudioOnly) Icons.Rounded.MusicNote else Icons.Rounded.Movie,
                                        contentDescription = null,
                                        tint = if (option.isAudioOnly) Color(0xFFFF9800) else accentColor,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column {
                                        Text(
                                            text = option.label,
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 14.sp
                                        )
                                        if (option.sizeBytes != null && option.sizeBytes > 0L) {
                                            Text(
                                                text = formatFileSize(option.sizeBytes),
                                                color = if (option.isAudioOnly) Color(0xFFFFB74D) else accentColor,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                                
                                Icon(
                                    imageVector = Icons.Rounded.Download,
                                    contentDescription = stringResource(R.string.downloads_title),
                                    tint = Color(0xFF8E9AA8),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    if (isLandscape) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 180.dp)
                        ) {
                            // Left side: Description + Switch (scrollable if needed)
                            val leftScroll = rememberScrollState()
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .verticalScroll(leftScroll),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = stringResource(R.string.video_player_download_desc),
                                    color = Color(0xFF8E9AA8),
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                                
                                // Switch for saving to secure private vault locker
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF16222F))
                                        .border(BorderStroke(0.5.dp, Color(0xFF23374A)), RoundedCornerShape(10.dp))
                                        .clickable { downloadToLocker = !downloadToLocker }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Lock,
                                            contentDescription = null,
                                            tint = if (downloadToLocker) accentColor else Color(0xFF8E9AA8),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Column {
                                            Text(
                                                text = stringResource(R.string.video_player_save_to_locker),
                                                color = Color.White,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = stringResource(R.string.video_player_encrypt_desc),
                                                color = Color(0xFF8E9AA8),
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                    Switch(
                                        checked = downloadToLocker,
                                        onCheckedChange = { downloadToLocker = it },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.White,
                                            checkedTrackColor = accentColor,
                                            uncheckedThumbColor = Color(0xFF8E9AA8),
                                            uncheckedTrackColor = Color(0xFF070A0F)
                                        ),
                                        modifier = Modifier.scale(0.8f)
                                    )
                                }
                            }
                            
                            // Right side: Scrollable qualities list
                            val rightScroll = rememberScrollState()
                            Column(
                                modifier = Modifier
                                    .weight(1.1f)
                                    .verticalScroll(rightScroll),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                qualityOptions.forEach { option ->
                                    qualityItemContent(option)
                                }
                            }
                        }
                    } else {
                        // Portrait view: original scrollable column
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                                .verticalScroll(scrollState)
                        ) {
                            Text(
                                text = stringResource(R.string.video_player_download_desc),
                                color = Color(0xFF8E9AA8),
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            
                            // Switch for saving to secure private vault locker
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF16222F))
                                    .border(BorderStroke(0.5.dp, Color(0xFF23374A)), RoundedCornerShape(10.dp))
                                    .clickable { downloadToLocker = !downloadToLocker }
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Lock,
                                        contentDescription = null,
                                        tint = if (downloadToLocker) accentColor else Color(0xFF8E9AA8),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column {
                                        Text(
                                            text = stringResource(R.string.video_player_save_to_locker),
                                            color = Color.White,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = stringResource(R.string.video_player_encrypt_desc),
                                            color = Color(0xFF8E9AA8),
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Switch(
                                    checked = downloadToLocker,
                                    onCheckedChange = { downloadToLocker = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = accentColor,
                                        uncheckedThumbColor = Color(0xFF8E9AA8),
                                        uncheckedTrackColor = Color(0xFF070A0F)
                                    )
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            qualityOptions.forEach { option ->
                                qualityItemContent(option)
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    OutlinedButton(
                        onClick = { showQualitySelector = false },
                        border = BorderStroke(0.5.dp, Color(0xFF16222F)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF8E9AA8)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    ) {
                        Text(stringResource(R.string.cancel_text), fontWeight = FontWeight.SemiBold)
                    }
                },
                containerColor = Color(0xFF0D1620),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.border(BorderStroke(0.5.dp, Color(0xFF16222F)), RoundedCornerShape(16.dp))
            )
        }

        // Progress Overlay (Visible for active downloads)
        if (isOnline && downloadEngine != null && currentJob != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 76.dp, end = 16.dp)
            ) {
                // Download Progress / Status Overlay Card
                val progressValue = progressState?.value
                Surface(
                    modifier = Modifier.width(180.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0D1620).copy(alpha = 0.85f),
                    border = BorderStroke(0.5.dp, Color(0xFF16222F))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.video_player_downloading),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = stringResource(R.string.cancel_text),
                                tint = Color(0xFF8E9AA8),
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable {
                                        downloadEngine.cancelDownload(currentJob.id)
                                        Toast.makeText(context, context.getString(R.string.video_player_download_cancelled), Toast.LENGTH_SHORT).show()
                                    }
                            )
                        }

                        when (progressValue) {
                            is com.rebelroot.omni.media.StreamDownloadEngine.DownloadProgress.Downloading -> {
                                val percent = progressValue.percent
                                val percentText = if (percent >= 0) "$percent%" else stringResource(R.string.video_player_downloading) + "..."
                                val sizeMb = progressValue.bytesDownloaded.toFloat() / (1024 * 1024)
                                
                                Text(
                                    text = "$percentText (${String.format("%.1f", sizeMb)} MB)",
                                    color = Color(0xFF8E9AA8),
                                    fontSize = 10.sp
                                )
                                if (percent >= 0) {
                                    LinearProgressIndicator(
                                        progress = { percent / 100f },
                                        modifier = Modifier.fillMaxWidth().height(3.dp),
                                        color = accentColor,
                                        trackColor = Color(0xFF16222F)
                                    )
                                } else {
                                    LinearProgressIndicator(
                                        modifier = Modifier.fillMaxWidth().height(3.dp),
                                        color = accentColor,
                                        trackColor = Color(0xFF16222F)
                                    )
                                }
                            }
                            is com.rebelroot.omni.media.StreamDownloadEngine.DownloadProgress.Muxing -> {
                                Text(
                                    text = progressValue.message,
                                    color = Color(0xFFFF9800),
                                    fontSize = 10.sp,
                                    lineHeight = 13.sp
                                )
                                LinearProgressIndicator(
                                    modifier = Modifier.fillMaxWidth().height(3.dp),
                                    color = Color(0xFFFF9800),
                                    trackColor = Color(0xFF16222F)
                                )
                            }
                            is com.rebelroot.omni.media.StreamDownloadEngine.DownloadProgress.Complete -> {
                                Text(
                                    text = stringResource(R.string.video_player_download_complete),
                                    color = Color(0xFF4CAF50),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                LaunchedEffect(Unit) {
                                    delay(2500)
                                    downloadEngine.cancelDownload(currentJob.id)
                                }
                            }
                            is com.rebelroot.omni.media.StreamDownloadEngine.DownloadProgress.Error -> {
                                Text(
                                    text = progressValue.message,
                                    color = Color(0xFFF44336),
                                    fontSize = 10.sp,
                                    lineHeight = 13.sp
                                )
                            }
                            null -> {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = accentColor,
                                    strokeWidth = 2.dp
                                )
                            }
                        }
                    }
                }
            }
        }
        } // end else
        } // end if (!isPiP) — no overlays rendered in PiP floating window
    }
}

private fun formatDuration(millis: Long): String {
    val sec = (millis / 1000) % 60
    val min = (millis / (1000 * 60)) % 60
    val hr = (millis / (1000 * 60 * 60))
    return if (hr > 0) {
        String.format("%d:%02d:%02d", hr, min, sec)
    } else {
        String.format("%02d:%02d", min, sec)
    }
}

/** Format bytes into a human-readable string (KB, MB, GB). */
private fun formatFileSize(bytes: Long): String {
    return when {
        bytes < 1_000L -> "$bytes B"
        bytes < 1_000_000L -> "%.0f KB".format(bytes / 1_000.0)
        bytes < 1_000_000_000L -> "%.1f MB".format(bytes / 1_000_000.0)
        else -> "%.2f GB".format(bytes / 1_000_000_000.0)
    }
}

@Composable
private fun translateQualityLabel(quality: String?): String {
    return when (quality) {
        "Source HD" -> stringResource(R.string.download_quality_source_hd)
        "Auto / Source" -> stringResource(R.string.download_quality_auto_source)
        "Unknown Quality" -> stringResource(R.string.download_quality_unknown)
        null -> stringResource(R.string.download_quality_auto)
        else -> quality
    }
}

private fun isDirectVideoUrl(url: String): Boolean {
    val clean = url.trim().lowercase()
    return clean.endsWith(".mp4") ||
            clean.endsWith(".m3u8") ||
            clean.endsWith(".mpd") ||
            clean.endsWith(".webm") ||
            clean.endsWith(".mkv") ||
            clean.endsWith(".ts") ||
            clean.contains(".mp4?") ||
            clean.contains(".m3u8?") ||
            clean.contains(".mpd?") ||
            clean.contains(".webm?") ||
            clean.contains(".mkv?") ||
            clean.contains(".ts?")
}

data class VideoQualityOption(
    val label: String,
    val url: String,
    val isAudioOnly: Boolean = false,
    val sizeBytes: Long? = null
)

private fun probeDirectStreamSize(urlStr: String, cookies: String?, referrer: String?): Long? {
    var currentUrl = urlStr
    var redirects = 0
    while (redirects < 4) {
        try {
            val url = java.net.URL(currentUrl)
            val conn = url.openConnection() as java.net.HttpURLConnection
            conn.instanceFollowRedirects = true
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.requestMethod = "HEAD"
            if (!cookies.isNullOrEmpty()) conn.setRequestProperty("Cookie", cookies)
            if (!referrer.isNullOrEmpty()) conn.setRequestProperty("Referer", referrer)
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            )
            conn.connect()
            val code = conn.responseCode
            if (code in 301..308) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (!loc.isNullOrEmpty()) {
                    currentUrl = if (loc.startsWith("http")) loc else java.net.URL(url, loc).toString()
                    redirects++
                    continue
                }
            }
            val len = conn.contentLengthLong.takeIf { it > 0 }
            conn.disconnect()
            if (len != null) return len

            // Fallback to GET bytes=0-1 range probe
            val getConn = java.net.URL(currentUrl).openConnection() as java.net.HttpURLConnection
            getConn.instanceFollowRedirects = true
            getConn.connectTimeout = 4000
            getConn.readTimeout = 4000
            getConn.requestMethod = "GET"
            getConn.setRequestProperty("Range", "bytes=0-1")
            if (!cookies.isNullOrEmpty()) getConn.setRequestProperty("Cookie", cookies)
            if (!referrer.isNullOrEmpty()) getConn.setRequestProperty("Referer", referrer)
            getConn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            )
            getConn.connect()
            val getCode = getConn.responseCode
            if (getCode in 301..308) {
                val loc = getConn.getHeaderField("Location")
                getConn.disconnect()
                if (!loc.isNullOrEmpty()) {
                    currentUrl = if (loc.startsWith("http")) loc else java.net.URL(url, loc).toString()
                    redirects++
                    continue
                }
            }
            val contentRange = getConn.getHeaderField("Content-Range")
            val total = contentRange?.substringAfterLast("/", "")?.trim()?.toLongOrNull()?.takeIf { it > 0 }
            val fallbackLen = getConn.contentLengthLong.takeIf { it > 0 }
            getConn.disconnect()
            return total ?: fallbackLen
        } catch (_: Exception) {
            return null
        }
    }
    return null
}

private suspend fun fetchVideoQualities(
    streamUrl: String,
    cookies: String?,
    sourceHdLabel: String,
    sourceStreamLabel: String,
    extractAudioLabel: String,
    durationMs: Long = 0L,
    activeBitrate: Int = -1,
    referrer: String? = null
): List<VideoQualityOption> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    val options = mutableListOf<VideoQualityOption>()
    val baseDurationSec = if (durationMs > 0) durationMs / 1000.0 else 0.0

    if (!streamUrl.contains(".m3u8")) {
        val directSize = probeDirectStreamSize(streamUrl, cookies, referrer)
        val fallbackVideoSize = if (directSize != null && directSize > 0) {
            directSize
        } else if (activeBitrate > 0 && baseDurationSec > 0) {
            ((activeBitrate / 8.0) * baseDurationSec).toLong()
        } else null

        val audioSize = if (baseDurationSec > 0) (16_000.0 * baseDurationSec).toLong() else null

        options.add(VideoQualityOption(sourceHdLabel, streamUrl, sizeBytes = fallbackVideoSize))
        options.add(VideoQualityOption(extractAudioLabel, streamUrl, isAudioOnly = true, sizeBytes = audioSize))
        return@withContext options
    }

    try {
        val connection = java.net.URL(streamUrl).openConnection() as java.net.HttpURLConnection
        connection.connectTimeout = 5000
        connection.readTimeout = 5000
        if (!cookies.isNullOrEmpty()) {
            connection.setRequestProperty("Cookie", cookies)
        }
        if (!referrer.isNullOrEmpty()) {
            connection.setRequestProperty("Referer", referrer)
        }
        connection.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        )
        connection.connect()
        val manifestContent = connection.inputStream.bufferedReader().use { it.readText() }

        val lines = manifestContent.lines()
        val baseUri = streamUrl.substring(0, streamUrl.lastIndexOf("/") + 1)

        var isMasterPlaylist = false
        var currentResolution = ""
        var currentBandwidth = 0L

        var manifestDurationSec = 0.0
        val segmentUrls = mutableListOf<String>()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXT-X-STREAM-INF")) {
                isMasterPlaylist = true
                val resMatch = Regex("RESOLUTION=(\\d+x\\d+)").find(trimmed)
                if (resMatch != null) {
                    val res = resMatch.groupValues[1]
                    val height = res.substringAfter("x").toIntOrNull() ?: 0
                    currentResolution = "${height}p"
                }
                val bwMatch = Regex("BANDWIDTH=(\\d+)").find(trimmed)
                if (bwMatch != null) {
                    val bw = bwMatch.groupValues[1].toLongOrNull() ?: 0L
                    currentBandwidth = bw
                    if (currentResolution.isEmpty()) {
                        currentResolution = "${bw / 1000}kbps"
                    }
                }
            } else if (trimmed.startsWith("#EXTINF:")) {
                val durStr = trimmed.substringAfter("#EXTINF:").substringBefore(",").trim()
                durStr.toDoubleOrNull()?.let { manifestDurationSec += it }
            } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                if (isMasterPlaylist && currentResolution.isNotEmpty()) {
                    val fullUrl = if (trimmed.startsWith("http")) trimmed else "$baseUri$trimmed"
                    val estimatedBytes = if (currentBandwidth > 0 && baseDurationSec > 0) {
                        ((currentBandwidth / 8.0) * baseDurationSec).toLong()
                    } else null
                    options.add(VideoQualityOption(currentResolution, fullUrl, sizeBytes = estimatedBytes))
                    currentResolution = ""
                    currentBandwidth = 0L
                } else {
                    segmentUrls.add(if (trimmed.startsWith("http")) trimmed else "$baseUri$trimmed")
                }
            }
        }

        val effectiveDurationSec = if (manifestDurationSec > 0) manifestDurationSec else baseDurationSec

        if (!isMasterPlaylist && segmentUrls.isNotEmpty()) {
            val firstSegBytes = probeDirectStreamSize(segmentUrls.first(), cookies, referrer)
            var computedSize: Long? = null
            if (firstSegBytes != null && firstSegBytes > 0) {
                computedSize = firstSegBytes * segmentUrls.size
            } else if (activeBitrate > 0 && effectiveDurationSec > 0) {
                computedSize = ((activeBitrate / 8.0) * effectiveDurationSec).toLong()
            } else if (effectiveDurationSec > 0) {
                val inferredRate = when {
                    streamUrl.contains("1080", ignoreCase = true) -> 500_000L
                    streamUrl.contains("720", ignoreCase = true) -> 250_000L
                    streamUrl.contains("480", ignoreCase = true) -> 125_000L
                    streamUrl.contains("360", ignoreCase = true) -> 75_000L
                    else -> 200_000L
                }
                computedSize = (inferredRate * effectiveDurationSec).toLong()
            }

            val label = when {
                streamUrl.contains("1080", ignoreCase = true) -> "1080p (Source)"
                streamUrl.contains("720", ignoreCase = true) -> "720p (Source)"
                streamUrl.contains("480", ignoreCase = true) -> "480p (Source)"
                streamUrl.contains("360", ignoreCase = true) -> "360p (Source)"
                else -> sourceStreamLabel
            }
            options.add(VideoQualityOption(label, streamUrl, sizeBytes = computedSize))
        }

        val audioBytes = if (effectiveDurationSec > 0) (16_000.0 * effectiveDurationSec).toLong() else null
        options.add(VideoQualityOption(extractAudioLabel, streamUrl, isAudioOnly = true, sizeBytes = audioBytes))

    } catch (e: Exception) {
        android.util.Log.e("VideoPlayer", "Failed to parse HLS variants in player", e)
    }

    if (options.isEmpty()) {
        val audioBytes = if (baseDurationSec > 0) (16_000.0 * baseDurationSec).toLong() else null
        options.add(VideoQualityOption(sourceStreamLabel, streamUrl))
        options.add(VideoQualityOption(extractAudioLabel, streamUrl, isAudioOnly = true, sizeBytes = audioBytes))
    }

    return@withContext options.distinctBy { it.label }
}

data class TrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val isSelected: Boolean,
    val mediaTrackGroup: androidx.media3.common.TrackGroup
)

private fun getYouTubeVideoId(url: String): String? {
    val clean = url.trim()
    if (clean.contains("youtube.com/watch")) {
        return try { android.net.Uri.parse(clean).getQueryParameter("v") } catch(e: Exception) { null }
    }
    if (clean.contains("youtu.be/")) {
        return clean.substringAfter("youtu.be/").substringBefore("?").substringBefore("/")
    }
    if (clean.contains("youtube.com/shorts/")) {
        return clean.substringAfter("youtube.com/shorts/").substringBefore("?").substringBefore("/")
    }
    if (clean.contains("youtube.com/embed/")) {
        return clean.substringAfter("youtube.com/embed/").substringBefore("?").substringBefore("/")
    }
    if (clean.contains("youtube.com/live/")) {
        return clean.substringAfter("youtube.com/live/").substringBefore("?").substringBefore("/")
    }
    if (clean.contains("googlevideo.com")) {
        // googlevideo.com stream URLs don't reliably contain the video_id; rely on page URL instead
        return try { android.net.Uri.parse(clean).getQueryParameter("video_id")
            ?: android.net.Uri.parse(clean).getQueryParameter("docid")
            ?: android.net.Uri.parse(clean).getQueryParameter("id") } catch(e: Exception) { null }
    }
    return null
}

