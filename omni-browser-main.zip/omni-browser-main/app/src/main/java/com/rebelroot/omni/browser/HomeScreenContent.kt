/*
 * Omni Browser - A premium, private, and secure web browser.
 * Copyright (C) 2026 RebelRoot Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.rebelroot.omni.browser

import android.app.Activity
import android.net.Uri
import android.view.ViewGroup
import android.widget.Toast
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.paint
import coil.compose.rememberAsyncImagePainter
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.rebelroot.omni.settings.AnimatedWallpaperBackground
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.blur
import androidx.compose.ui.viewinterop.AndroidView

import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import org.mozilla.geckoview.GeckoView
import com.rebelroot.omni.R
import com.rebelroot.omni.media.MediaInterceptor
import com.rebelroot.omni.privacy.FireButton
import com.rebelroot.omni.tools.qrcode.BarcodeGenerator
import android.graphics.Bitmap
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.drawWithContent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import android.content.ContentValues
import android.provider.MediaStore
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.channels.Channel
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
 import androidx.compose.foundation.gestures.rememberTransformableState
 import androidx.compose.foundation.gestures.transformable
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback


@Composable
fun TabItem(
    title: String,
    isActive: Boolean,
    onClick: () -> Unit,
    onClose: () -> Unit
) {
    Surface(
        modifier = Modifier
            .padding(horizontal = 3.dp, vertical = 3.dp)
            .height(32.dp)
            .widthIn(max = 120.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(
                BorderStroke(
                    0.5.dp,
                    if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                ),
                RoundedCornerShape(20.dp)
            )
            .clickable { onClick() },
        color = if (isActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Language,
                contentDescription = null,
                modifier = Modifier.size(12.dp),
                tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f, fill = false)
            )
            IconButton(
                onClick = onClose,
                modifier = Modifier.size(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.close_tab_desc),
                    modifier = Modifier.size(8.dp),
                    tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun HomeScreenContent(
    viewModel: BrowserViewModel,
    onOpenDownloads: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenLocker: () -> Unit,
    onOpenQrTools: () -> Unit,
    onOpenExtensions: () -> Unit,
    onOpenTranslator: () -> Unit,
    onOpenConsole: () -> Unit,
    onNavigateTo: (String) -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    showMenu: Boolean,
    onShowMenuChange: (Boolean) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPasswordManager: () -> Unit,
    showCustomizationSheet: Boolean,
    onShowCustomizationSheetChange: (Boolean) -> Unit,
    onShowTabGroups: () -> Unit = {},
    onOpenWallpapers: () -> Unit = {},
    onOpenAppearance: () -> Unit = {},
    onShowThemeSheet: () -> Unit = {},
    onShowQuickTools: () -> Unit = {},
    onShowFeedbackDialog: () -> Unit = {},
    onShowPlayerSettings: () -> Unit = {},
    onBurnData: () -> Unit = {},
    onOpenWebApps: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
    val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    var searchText by remember { mutableStateOf(androidx.compose.ui.text.input.TextFieldValue("")) }
    LaunchedEffect(searchText.text) {
        viewModel.fetchSearchSuggestions(searchText.text)
    }
    LaunchedEffect(viewModel.activeTabId, viewModel.currentUrl) {
        if (viewModel.currentUrl == "about:blank" || viewModel.currentUrl.isEmpty()) {
            searchText = androidx.compose.ui.text.input.TextFieldValue("")
            viewModel.searchSuggestions.clear()
        }
    }
    var showHomeMenu by remember { mutableStateOf(false) }
    var showAddShortcutSheet by remember { mutableStateOf(false) }
    var shortcutsExpanded by remember { mutableStateOf(false) }
    var selectedShortcutForMenu by remember { mutableStateOf<HomeShortcut?>(null) }
    var showShortcutOptionsSheet by remember { mutableStateOf(false) }
    var showEditShortcutDialog by remember { mutableStateOf(false) }
    var showDeleteShortcutDialog by remember { mutableStateOf(false) }
    var showPrivacyReportSheet by remember { mutableStateOf(false) }

    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { result ->
            if (result.resultCode == android.app.Activity.RESULT_OK) {
                val data = result.data
                val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                val spokenText = results?.firstOrNull() ?: ""
                if (spokenText.isNotEmpty()) {
                    searchText = androidx.compose.ui.text.input.TextFieldValue("")
                    viewModel.searchSuggestions.clear()
                    focusManager.clearFocus()
                    keyboardController?.hide()
                    onNavigateTo(spokenText)
                }
            }
        }
    )

    // Shared search actions, used by both the top field and the bottom-docked field.
    val submitSearch: (String) -> Unit = { query ->
        searchText = androidx.compose.ui.text.input.TextFieldValue("")
        viewModel.searchSuggestions.clear()
        focusManager.clearFocus()
        keyboardController?.hide()
        onNavigateTo(query)
    }
    val clearSearch: () -> Unit = {
        searchText = androidx.compose.ui.text.input.TextFieldValue("")
        viewModel.searchSuggestions.clear()
    }
    val refineSearch: (String) -> Unit = { suggestion ->
        searchText = androidx.compose.ui.text.input.TextFieldValue(
            suggestion,
            androidx.compose.ui.text.TextRange(suggestion.length)
        )
    }
    val launchLens: () -> Unit = {
        try {
            val intent = Intent("com.google.lens.intent.action.LENS_INPUT").apply {
                setPackage("com.google.android.googlequicksearchbox")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    setClassName("com.google.ar.lens", "com.google.vr.apps.ornament.app.lens.LensLauncherActivity")
                }
                context.startActivity(intent)
            } catch (ex: Exception) {
                onOpenQrTools()
            }
        }
    }
    val launchVoice: () -> Unit = {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toString())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to search...")
            }
            speechRecognizerLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Voice search is not supported on this device", Toast.LENGTH_SHORT).show()
        }
    }

    val baseDensity = androidx.compose.ui.platform.LocalDensity.current
    val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    val isTablet = screenWidthDp >= 600
    // Bottom-docked search layout: search pill floats above the keyboard, and the
    // home bottom nav bar is hidden (its actions all live in the 3-dot menu).
    val searchAtBottom = viewModel.homeSearchBarAtBottom
    val navHidden = viewModel.hideHomeBottomNav || searchAtBottom

    // Measured geometry used to vertically balance the bottom-search layout: the
    // brand + tiles + widget are centred in the space between the top icon row and
    // the docked search bar, instead of being packed against the top.
    var homeViewportPx by remember { mutableStateOf(0) }
    var homeHeaderPx by remember { mutableStateOf(0) }
    var homeBodyPx by remember { mutableStateOf(0) }
    val homeDensity = androidx.compose.ui.platform.LocalDensity.current
    val homeCenterSpacer = if (!searchAtBottom) 0.dp else {
        val statusTopPx = androidx.compose.foundation.layout.WindowInsets.statusBars.getTop(homeDensity)
        val barClearancePx = with(homeDensity) { 92.dp.toPx() }
        val regionPx = homeViewportPx - statusTopPx - barClearancePx - homeHeaderPx
        if (homeBodyPx <= 0 || regionPx <= homeBodyPx) 0.dp
        else with(homeDensity) { ((regionPx - homeBodyPx) / 2f).toDp() }
    }
    val responsiveWidthFactor = remember(screenWidthDp) {
        if (isTablet) 1.0f
        else (screenWidthDp / 390f).coerceIn(0.85f, 1.05f)
    }
    val effectiveHomeScale = remember(viewModel.homeUiScale, responsiveWidthFactor) {
        (viewModel.homeUiScale * responsiveWidthFactor).coerceIn(0.72f, if (isTablet) 1.0f else 1.10f)
    }
    val scaledDensity = remember(baseDensity, effectiveHomeScale) {
        androidx.compose.ui.unit.Density(
            density = baseDensity.density * effectiveHomeScale,
            fontScale = baseDensity.fontScale * effectiveHomeScale
        )
    }

    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides scaledDensity
    ) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (viewModel.browserWallpaperUri != null && !viewModel.isIncognitoMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clipToBounds()
            ) {
                com.rebelroot.omni.settings.AnimatedWallpaperBackground(
                    wallpaperUri = viewModel.browserWallpaperUri!!,
                    scale = viewModel.wallpaperScale,
                    offsetX = viewModel.wallpaperOffsetX,
                    offsetY = viewModel.wallpaperOffsetY,
                    blur = viewModel.wallpaperBlur
                )
            }
            val userDim = if (viewModel.wallpaperDim >= 0f) viewModel.wallpaperDim else 0.20f
            val effectiveDim = userDim  // Allow 0% — user slider range is 0f..0.9f
            val overlayColor = Color.Black.copy(alpha = effectiveDim)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(overlayColor)
            )
        }

        // These are now handled by LocalDensity scaling — use fixed dp values
        val scaledLogoHeight = 100.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (viewModel.isIncognitoMode) {
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF161320), Color(0xFF0C0A10))
                        )
                    } else if (viewModel.browserWallpaperUri != null) {
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Transparent)
                        )
                    } else {
                        Brush.verticalGradient(
                            colors = listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.background)
                        )
                    }
                )
                .onGloballyPositioned { homeViewportPx = it.size.height },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
        Column(
            modifier = Modifier
                .widthIn(max = if (isTablet) 720.dp else Int.MAX_VALUE.dp)
                .fillMaxHeight()
                // Foreground content clears the notch; the wallpaper itself is drawn
                // by the fillMaxSize background above (BrowserScreen no longer insets
                // the home screen), so the cutout area shows the wallpaper.
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                // Extra bottom clearance when the transparent home bottom bar is
                // visible, so the last rows can scroll clear of it on small
                // screens instead of being overlapped mid-list.
                .padding(
                    start = 24.dp,
                    end = 24.dp,
                    bottom = when {
                        searchAtBottom -> 92.dp
                        viewModel.showBottomNavBar && !viewModel.hideHomeBottomNav ->
                            24.dp + (52 * viewModel.bottomNavScale).dp
                        else -> 24.dp
                    },
                    top = 0.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, start = 4.dp, end = 4.dp)
                    .onGloballyPositioned { homeHeaderPx = it.size.height },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Far Left: Palette (when nav hidden) or Extensions (when nav visible).
                // Tablets always get an explicit palette shortcut here — the bottom
                // nav is replaced by the rail on large screens, so the customize
                // entry would otherwise only live inside the rail.
                if (isTablet) {
                    // Tablet home: extensions + always-visible palette shortcut.
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        if (!navHidden) {
                            IconButton(
                                onClick = { onOpenExtensions() },
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Extension,
                                    contentDescription = "Extensions",
                                    tint = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        IconButton(
                            onClick = { onShowCustomizationSheetChange(true) },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Palette,
                                contentDescription = "Customize Home",
                                tint = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                } else if (navHidden) {
                    // Phone: palette only when the bottom nav is hidden.
                    IconButton(
                        onClick = { onShowCustomizationSheetChange(true) },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Palette,
                            contentDescription = "Customize Home",
                            tint = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                } else {
                    IconButton(
                        onClick = { onOpenExtensions() },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Extension,
                            contentDescription = "Extensions",
                            tint = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Far Right: Tabs Button + 3-Dot Menu Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Tabs Button (showing tab count badge)
                    IconButton(
                        onClick = { onShowTabGroups() },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .border(
                                    1.5.dp,
                                    if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                                    RoundedCornerShape(6.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${viewModel.tabs.size.coerceAtLeast(1)}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                        }
                    }

                    Box {
                        IconButton(
                            onClick = {
                                focusManager.clearFocus()
                                keyboardController?.hide()
                                showHomeMenu = true
                            },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.MoreVert,
                                contentDescription = "Menu",
                                tint = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        omnimenuDropdown(
                            expanded = showHomeMenu,
                            onDismissRequest = { showHomeMenu = false },
                            viewModel = viewModel,
                            onNewTab = { showHomeMenu = false; viewModel.createNewTab(context, "about:blank") },
                            onNewIncognitoTab = {
                                showHomeMenu = false
                                if (!viewModel.isIncognitoMode) {
                                    viewModel.toggleIncognitoMode(context)
                                }
                                viewModel.createNewTab(context, "about:blank")
                            },
                            onOpenHistory = { showHomeMenu = false; onOpenHistory() },
                            onBurnData = { showHomeMenu = false; onBurnData() },
                            onOpenDownloads = { showHomeMenu = false; onOpenDownloads() },
                            onOpenBookmarks = { showHomeMenu = false; onOpenBookmarks() },
                            onOpenSettings = { showHomeMenu = false; onOpenSettings() },
                            onOpenWebApps = { showHomeMenu = false; onOpenWebApps() },
                            onOpenPasswordManager = { showHomeMenu = false; onOpenPasswordManager() },
                            onShowThemeSheet = { showHomeMenu = false; onShowThemeSheet() },
                            onShowFeedbackDialog = { showHomeMenu = false; onShowFeedbackDialog() },
                            onShowCustomizationSheet = { showHomeMenu = false; onShowCustomizationSheetChange(true) },
                            onShowExtensions = { showHomeMenu = false; onOpenExtensions() },
                            onShowPlayerSettings = { showHomeMenu = false; onShowPlayerSettings() },
                            onShowSiteInfo = { showHomeMenu = false },
                            onFindInPage = {}
                        )
                    }
                }
            }

        // Branding + tiles + widget, measured as one block so the bottom-search
        // layout can centre it in the space above the docked bar.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = homeCenterSpacer)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .onGloballyPositioned { homeBodyPx = it.size.height },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(28.dp)
            ) {
        if (viewModel.isIncognitoMode) {
            // Incognito Branding
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF282335)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VisibilityOff,
                        contentDescription = stringResource(R.string.incognito_mode_desc),
                        tint = Color(0xFFCBB2FF),
                        modifier = Modifier.size(44.dp)
                    )
                }
                Text(
                    text = stringResource(R.string.incognito_screen_title),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = stringResource(R.string.incognito_description),
                    color = Color(0xFF9186A8),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }

        val contentModifier = Modifier.fillMaxWidth()

        Column(
            modifier = contentModifier,
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
        val historyList = viewModel.historyList
        // Home sections are emitted in the user's order (home_sections_layout).
        viewModel.homeSectionsLayout.forEach { sectionId ->
        when (sectionId) {
        "section_logo" -> if (!viewModel.isIncognitoMode) {
            // Center branding OMNI stylized logo Image or Custom Cropped Image
            if (viewModel.customIconPath != null) {
                coil.compose.AsyncImage(
                    model = java.io.File(viewModel.customIconPath!!),
                    contentDescription = "Omni Browser Custom Logo",
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(
                        id = if (viewModel.isDarkThemeEnabled) {
                            com.rebelroot.omni.R.drawable.omni_home_logo
                        } else {
                            com.rebelroot.omni.R.drawable.omni_home_logo_light
                        }
                    ),
                    contentDescription = "Omni Browser Logo",
                    modifier = Modifier
                        .height(scaledLogoHeight)
                        .padding(horizontal = 16.dp),
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                )
            }
        }
        "section_search" -> {
        if (!searchAtBottom) {
            // Flat Slate search pill (top layout)
            HomeSearchField(
                viewModel = viewModel,
                searchText = searchText,
                onSearchTextChange = { searchText = it },
                onFocusChanged = onFocusChanged,
                onClear = clearSearch,
                onLens = launchLens,
                onVoice = launchVoice,
                onSubmit = { if (searchText.text.isNotEmpty()) submitSearch(searchText.text) },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (!searchAtBottom && searchText.text.isNotEmpty() && viewModel.searchSuggestions.isNotEmpty()) {
            HomeSearchSuggestions(
                viewModel = viewModel,
                onSelectSuggestion = submitSearch,
                onRefineSuggestion = refineSearch,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp)
            )
        }
        }
        "section_shortcuts" -> if (searchText.text.isEmpty() || viewModel.searchSuggestions.isEmpty()) {
            // Dynamic Grid of Shortcuts — 5 per row, icon-only, no border boxes
            // Shows up to 15 items collapsed; "More" expands to show all.
            val shortcuts = viewModel.shortcutsList

            val columnsCount = when {
                viewModel.homeUiScale >= 1.2f -> 3
                viewModel.homeUiScale <= 0.85f -> 5
                else -> 4
            }
            // Collapse limit: 2 full rows worth of items
            val collapseLimit = columnsCount * 2
            val allItems = remember(shortcuts.toList()) {
                shortcuts.toList() + HomeShortcut(id = "add_shortcut_btn", title = "Add", url = "add")
            }
            // Items to display: collapse at 2 rows unless expanded (keep "Add" always last)
            val visibleItems = remember(allItems, shortcutsExpanded, columnsCount) {
                val realItems = allItems.dropLast(1) // all except Add btn
                val addBtn   = allItems.last()
                val showMore = realItems.size > collapseLimit && !shortcutsExpanded
                val capped   = if (showMore) realItems.take(collapseLimit) else realItems
                capped + addBtn
            }
            val hasMore = allItems.size - 1 > collapseLimit && !shortcutsExpanded  // -1 for Add btn
            val shortcutRows = remember(visibleItems, columnsCount) { visibleItems.chunked(columnsCount) }
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                shortcutRows.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        rowItems.forEach { shortcut ->
                            Box(
                                modifier = Modifier.weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                when {
                                    shortcut.id == "add_shortcut_btn" -> {
                                        CompactShortcutItem(
                                            title = stringResource(id = R.string.add_title),
                                            icon = Icons.Rounded.Add,
                                            tileStyle = viewModel.shortcutTileStyle,
                                            hasWallpaper = viewModel.browserWallpaperUri != null,
                                            onClick = { showAddShortcutSheet = true }
                                        )
                                    }
                                    shortcut.isFeature -> {
                                        val (icon, isAccented, action) = when (shortcut.id.lowercase()) {
                                            "downloads" -> Triple(Icons.Rounded.Download, true, onOpenDownloads)
                                            "history"   -> Triple(Icons.Rounded.History,  false, onOpenHistory)
                                            "bookmarks" -> Triple(Icons.Rounded.Bookmark, false, onOpenBookmarks)
                                            "web_apps", "webapps" -> Triple(Icons.Rounded.Apps, false, onOpenWebApps)
                                            "incognito" -> Triple(
                                                if (viewModel.isIncognitoMode) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                                false,
                                                { viewModel.toggleIncognitoMode(context) }
                                            )
                                            else -> Triple(Icons.Rounded.Extension, false, {})
                                        }
                                        val downloadsStr = stringResource(id = R.string.downloads_title)
                                        val historyStr   = stringResource(id = R.string.history_title)
                                        val bookmarksStr = stringResource(id = R.string.bookmarks_title)
                                        val webAppsStr   = stringResource(id = R.string.tool_web_apps)
                                        val incognitoStr = stringResource(id = R.string.incognito_title)

                                        val displayTitle = when (shortcut.id.lowercase()) {
                                            "downloads" -> downloadsStr
                                            "history"   -> historyStr
                                            "bookmarks" -> bookmarksStr
                                            "web_apps", "webapps" -> webAppsStr
                                            "incognito" -> incognitoStr
                                            else        -> when (shortcut.title) {
                                                "Downloads" -> downloadsStr
                                                "History"   -> historyStr
                                                "Bookmarks" -> bookmarksStr
                                                "Web Apps"  -> webAppsStr
                                                "Incognito" -> incognitoStr
                                                else        -> shortcut.title
                                            }
                                        }
                                        CompactShortcutItem(
                                            title = displayTitle,
                                            icon = icon,
                                            isAccented = isAccented,
                                            tileStyle = viewModel.shortcutTileStyle,
                                            hasWallpaper = viewModel.browserWallpaperUri != null,
                                            onClick = action
                                        )
                                    }
                                    else -> {
                                        CompactDynamicShortcutItem(
                                            title = shortcut.title,
                                            url = shortcut.url,
                                            tileStyle = viewModel.shortcutTileStyle,
                                            hasWallpaper = viewModel.browserWallpaperUri != null,
                                            onClick = { onNavigateTo(shortcut.url) },
                                            onLongClick = {
                                                if (!shortcut.isPermanent) {
                                                    selectedShortcutForMenu = shortcut
                                                    showShortcutOptionsSheet = true
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        if (rowItems.size < columnsCount) {
                            repeat(columnsCount - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }

            if (hasMore || shortcutsExpanded) {
                TextButton(
                    onClick = { shortcutsExpanded = !shortcutsExpanded },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(
                        text = if (shortcutsExpanded) "Show less" else stringResource(id = R.string.home_more),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Recently Visited Section matching screenshot
        "section_recents" -> if (historyList.isNotEmpty() && !viewModel.isMinimalistFocusMode && !viewModel.isIncognitoMode && (searchText.text.isEmpty() || viewModel.searchSuggestions.isEmpty())) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(id = R.string.home_recently_visited),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (viewModel.browserWallpaperUri != null || viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                        style = androidx.compose.ui.text.TextStyle(
                            shadow = if (viewModel.browserWallpaperUri != null) androidx.compose.ui.graphics.Shadow(
                                color = Color.Black.copy(alpha = 0.85f),
                                offset = androidx.compose.ui.geometry.Offset(0f, 2f),
                                blurRadius = 4f
                            ) else null
                        )
                    )
                    Text(
                        text = stringResource(id = R.string.home_see_all),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable { onOpenHistory() }
                    )
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = 2.dp)
                ) {
                    items(historyList.take(10)) { item ->
                        val domain = remember(item.url) {
                            try { Uri.parse(item.url).host ?: item.url } catch (e: Exception) { item.url }
                        }
                        val faviconUrl = "https://www.google.com/s2/favicons?sz=128&domain=$domain"
                        val tileStyle = viewModel.shortcutTileStyle
                        val tileShape = when (tileStyle) {
                            "Squircle" -> RoundedCornerShape(14.dp)
                            "Square"   -> RoundedCornerShape(6.dp)
                            "Glass"    -> RoundedCornerShape(14.dp)
                            else       -> CircleShape
                        }
                        val isGlass = tileStyle == "Glass"
                        val hasWallpaper = viewModel.browserWallpaperUri != null
                        val domainInitial = domain.removePrefix("www.").firstOrNull()?.uppercaseChar()?.toString() ?: "?"
                        val tileColor = remember(domain) {
                            val colors = listOf(
                                Color(0xFF4285F4), Color(0xFF34A853), Color(0xFFEA4335),
                                Color(0xFFFBBC05), Color(0xFF9C27B0), Color(0xFF00BCD4),
                                Color(0xFFFF5722), Color(0xFF607D8B), Color(0xFF795548)
                            )
                            colors[(domain.hashCode() and 0x7FFFFFFF) % colors.size]
                        }
                        val tileBg = when {
                            hasWallpaper || isGlass -> Color(0xFF101216).copy(alpha = 0.40f)
                            else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                        }
                        val tileBorderColor = if (hasWallpaper || isGlass) Color.White.copy(alpha = 0.18f) else Color.Transparent

                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(tileShape)
                                .background(tileBg)
                                .then(
                                    if (hasWallpaper || isGlass) Modifier.border(0.5.dp, tileBorderColor, tileShape)
                                    else Modifier
                                )
                                .clickable { onNavigateTo(item.url) },
                            contentAlignment = Alignment.Center
                        ) {
                            var faviconLoaded by remember(faviconUrl) { mutableStateOf(false) }
                            if (!faviconLoaded) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(tileColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = domainInitial,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            coil.compose.AsyncImage(
                                model = coil.request.ImageRequest.Builder(LocalContext.current)
                                    .data(faviconUrl)
                                    .size(128, 128)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = item.title,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape),
                                onSuccess = { faviconLoaded = true },
                                onError = { faviconLoaded = false }
                            )
                        }
                    }
                }
            }
        }

        // Privacy Shield Card — Premium redesign
        "section_privacy" -> if (!viewModel.isMinimalistFocusMode && !viewModel.isIncognitoMode && (searchText.text.isEmpty() || viewModel.searchSuggestions.isEmpty())) {
            val isDark = viewModel.isDarkThemeEnabled
            val hasWallpaper = viewModel.browserWallpaperUri != null
            val cardBg = if (hasWallpaper) {
                Color(0xFF101216).copy(alpha = 0.45f)
            } else {
                if (isDark) Color(0xFF1C1C1E) else Color(0xFFF1F3F4)
            }
            val borderColor = if (hasWallpaper) {
                Color.White.copy(alpha = 0.18f)
            } else {
                Color.Transparent
            }
            val dividerColor = if (hasWallpaper) Color.White.copy(alpha = 0.12f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
            val labelColor = if (hasWallpaper) Color.White.copy(alpha = 0.85f) else (if (isDark) Color(0xFF8E8E93) else Color(0xFF555555))
            val valueColor = Color.White

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp, vertical = 2.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(cardBg)
                    .then(
                        if (borderColor != Color.Transparent) {
                            Modifier.border(0.6.dp, borderColor, RoundedCornerShape(18.dp))
                        } else {
                            Modifier
                        }
                    )
                    .clickable { showPrivacyReportSheet = true }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Top row: status + cta
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = null,
                                tint = if (hasWallpaper) Color.White.copy(alpha = 0.90f) else (if (isDark) Color(0xFF8E8E93) else Color(0xFF6E6E73)),
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = stringResource(R.string.home_shield_active),
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (hasWallpaper) Color.White.copy(alpha = 0.90f) else (if (isDark) Color(0xFF8E8E93) else Color(0xFF555555))
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.home_view_report_short),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(10.dp)
                            )
                        }
                    }

                    // Stats row - horizontal side-by-side layout
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Trackers Blocked
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Shield,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = "${viewModel.trackersBlockedCount}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = valueColor
                                )
                                Text(
                                    text = stringResource(R.string.home_trackers_blocked),
                                    fontSize = 10.sp,
                                    color = labelColor,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Vertical divider
                        Box(
                            modifier = Modifier
                                .width(0.6.dp)
                                .height(26.dp)
                                .background(dividerColor)
                                .align(Alignment.CenterVertically)
                        )

                        // Data Saved
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .padding(start = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Speed,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = "${(viewModel.trackersBlockedCount * 1.5).toInt()} MB",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = valueColor
                                )
                                Text(
                                    text = stringResource(R.string.home_data_saved),
                                    fontSize = 10.sp,
                                    color = labelColor,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        }
        }
        }

        // Shortcut long-press Options Sheet
        if (showShortcutOptionsSheet && selectedShortcutForMenu != null) {
            ModalBottomSheet(
                onDismissRequest = {
                    showShortcutOptionsSheet = false
                    selectedShortcutForMenu = null
                },
                containerColor = if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = selectedShortcutForMenu!!.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = if (viewModel.isDarkThemeEnabled) Color.White else Color.Black,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showShortcutOptionsSheet = false
                                showEditShortcutDialog = true
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = "Edit Shortcut",
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Edit Shortcut",
                            color = if (viewModel.isDarkThemeEnabled) Color.White else Color.Black,
                            fontSize = 14.sp
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showShortcutOptionsSheet = false
                                showDeleteShortcutDialog = true
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Delete,
                            contentDescription = "Remove Shortcut",
                            tint = Color.Red
                        )
                        Text(
                            text = "Remove Shortcut",
                            color = Color.Red,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Edit Shortcut Dialog
        if (showEditShortcutDialog && selectedShortcutForMenu != null) {
            var editName by remember { mutableStateOf(selectedShortcutForMenu!!.title) }
            var editUrl by remember { mutableStateOf(selectedShortcutForMenu!!.url) }
            AlertDialog(
                onDismissRequest = {
                    showEditShortcutDialog = false
                    selectedShortcutForMenu = null
                },
                title = { Text("Edit Shortcut") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = editUrl,
                            onValueChange = { editUrl = it },
                            label = { Text("URL") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (editName.isNotBlank() && editUrl.isNotBlank()) {
                            viewModel.editShortcut(selectedShortcutForMenu!!, editName, editUrl)
                        }
                        showEditShortcutDialog = false
                        selectedShortcutForMenu = null
                    }) { Text("Save") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showEditShortcutDialog = false
                        selectedShortcutForMenu = null
                    }) { Text("Cancel") }
                }
            )
        }

        // Delete Shortcut Confirmation Dialog
        if (showDeleteShortcutDialog && selectedShortcutForMenu != null) {
            AlertDialog(
                onDismissRequest = {
                    showDeleteShortcutDialog = false
                    selectedShortcutForMenu = null
                },
                title = { Text("Delete Shortcut?") },
                text = { Text("Remove shortcut to ${selectedShortcutForMenu!!.title}?") },
                confirmButton = {
                    TextButton(onClick = {
                        viewModel.deleteShortcut(selectedShortcutForMenu!!)
                        showDeleteShortcutDialog = false
                        selectedShortcutForMenu = null
                    }) { Text("Delete", color = Color(0xFFFF3B30)) }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showDeleteShortcutDialog = false
                        selectedShortcutForMenu = null
                    }) { Text("Cancel") }
                }
            )
        }

        // Add to Home Bottom Sheet
        if (showAddShortcutSheet) {
            ModalBottomSheet(
                onDismissRequest = { showAddShortcutSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color.White
            ) {
                var nameInput by remember { mutableStateOf("") }
                var urlInput by remember { mutableStateOf("") }
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Add to Home",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF202124)
                        )
                        IconButton(onClick = { showAddShortcutSheet = false }) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF202124)
                            )
                        }
                    }
                    
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Shortcut Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(24.dp)
                        )
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = { urlInput = it },
                            label = { Text("Shortcut URL") },
                            placeholder = { Text("example.com") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(24.dp),
                            keyboardOptions = KeyboardOptions(
                                imeAction = androidx.compose.ui.text.input.ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    if (urlInput.isNotEmpty()) {
                                        val title = nameInput.ifEmpty { urlInput }
                                        viewModel.addShortcut(title, urlInput)
                                        showAddShortcutSheet = false
                                    }
                                }
                            )
                        )
                        Button(
                            onClick = {
                                if (urlInput.isNotEmpty()) {
                                    val title = nameInput.ifEmpty { urlInput }
                                    viewModel.addShortcut(title, urlInput)
                                    showAddShortcutSheet = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Text("Add Custom Shortcut", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    HorizontalDivider(color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))
                    
                    Text(
                        text = "Popular websites",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF202124)
                    )
                    
                    val popularSites = listOf(
                        Triple("Spotify", "https://spotify.com", Color(0xFF1DB954)),
                        Triple("Facebook", "https://facebook.com", Color(0xFF1877F2)),
                        Triple("Amazon", "https://amazon.com", Color(0xFFFF9900)),
                        Triple("Hulu", "https://hulu.com", Color(0xFF1CE783)),
                        Triple("Twitter", "https://twitter.com", Color(0xFF1DA1F2)),
                        Triple("eBay", "https://ebay.com", Color(0xFFE53238)),
                        Triple("Walmart", "https://walmart.com", Color(0xFF0071CE)),
                        Triple("Daily Mail", "https://dailymail.co.uk", Color(0xFF005689))
                    )
                    
                    val popularColumns = 4
                    val popularRows = remember(popularSites) { popularSites.chunked(popularColumns) }
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        popularRows.forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                rowItems.forEach { site ->
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        PopularSiteItem(
                                            title = site.first,
                                            domain = site.second,
                                            bgColor = site.third,
                                            onClick = {
                                                viewModel.addShortcut(site.first, site.second)
                                                showAddShortcutSheet = false
                                            }
                                        )
                                    }
                                }
                                if (rowItems.size < popularColumns) {
                                    repeat(popularColumns - rowItems.size) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
            }
        }


    }
    }

        // ── Bottom-docked search layout ──────────────────────────────────────
        // Pinned to the bottom of the content area and lifted above the IME, so
        // the field is thumb-reachable and stays visible while typing.
        if (searchAtBottom && "section_search" in viewModel.homeSectionsLayout) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (searchText.text.isNotEmpty() && viewModel.searchSuggestions.isNotEmpty()) {
                        HomeSearchSuggestions(
                            viewModel = viewModel,
                            onSelectSuggestion = submitSearch,
                            onRefineSuggestion = refineSearch,
                            maxItems = 6,
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(6.dp, RoundedCornerShape(18.dp))
                        )
                    }
                    HomeSearchField(
                        viewModel = viewModel,
                        searchText = searchText,
                        onSearchTextChange = { searchText = it },
                        onFocusChanged = onFocusChanged,
                        onClear = clearSearch,
                        onLens = launchLens,
                        onVoice = launchVoice,
                        onSubmit = { if (searchText.text.isNotEmpty()) submitSearch(searchText.text) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(6.dp, RoundedCornerShape(24.dp))
                    )
                }
            }
        }
    }

    // ── Premium Privacy Protection Report Sheet ─────────────────────────────────
    if (showPrivacyReportSheet) {
        val isDark = viewModel.isDarkThemeEnabled
        val sheetBg   = if (isDark) Color(0xFF161616) else Color(0xFFFAFAFA)
        val cardBg    = if (isDark) Color(0xFF1E1E1E) else Color(0xFFFFFFFF)
        val borderCol = if (isDark) Color(0xFF2A2A2A) else Color(0xFFEAEAEA)
        val titleCol  = if (isDark) Color(0xFFFFFFFF) else Color(0xFF111111)
        val subCol    = if (isDark) Color(0xFF9A9A9A) else Color(0xFF888888)
        val labelCol  = if (isDark) Color(0xFF707070) else Color(0xFF999999)

        ModalBottomSheet(
            onDismissRequest = { showPrivacyReportSheet = false },
            containerColor = sheetBg,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(top = 10.dp, bottom = 8.dp)
                        .width(32.dp).height(3.dp)
                        .clip(CircleShape)
                        .background(if (isDark) Color(0xFF3A3A3A) else Color(0xFFCCCCCC))
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Spacer(Modifier.height(4.dp))

                // ── Header ──────────────────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = stringResource(R.string.privacy_report_title),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = (-0.3).sp,
                            color = titleCol
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = null,
                                tint = subCol,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = stringResource(R.string.privacy_report_all_shields_active),
                                fontSize = 12.sp,
                                color = subCol
                            )
                        }
                    }
                }

                // ── Summary Stats Cards ──────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Trackers Blocked card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(cardBg)
                            .border(0.5.dp, borderCol, RoundedCornerShape(14.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "${viewModel.trackersBlockedCount}",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.8).sp,
                            color = titleCol
                        )
                        Text(
                            text = stringResource(R.string.home_trackers_blocked),
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = labelCol
                        )
                    }
                    // Data Saved card
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(cardBg)
                            .border(0.5.dp, borderCol, RoundedCornerShape(14.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Speed,
                            contentDescription = null,
                            tint = if (isDark) Color(0xFF888888) else Color(0xFF999999),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "${(viewModel.trackersBlockedCount * 1.5).toInt()} MB",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = (-0.8).sp,
                            color = titleCol
                        )
                        Text(
                            text = stringResource(R.string.privacy_report_bandwidth_saved),
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            color = labelCol
                        )
                    }
                }

                // ── Active Shields Section ──────────────────────────────
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.privacy_report_active_shields),
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = labelCol
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(cardBg)
                            .border(0.5.dp, borderCol, RoundedCornerShape(14.dp))
                    ) {
                        val shields = listOf(
                            Triple(Icons.Rounded.Block, stringResource(R.string.privacy_shield_ad_tracker_blocking), stringResource(R.string.privacy_shield_ad_tracker_desc, viewModel.trackersBlockedCount)),
                            Triple(Icons.Rounded.Lock, stringResource(R.string.privacy_shield_https_enforcement), stringResource(R.string.privacy_shield_https_desc)),
                            Triple(Icons.Rounded.Fingerprint, stringResource(R.string.privacy_shield_fingerprint), stringResource(R.string.privacy_shield_fingerprint_desc)),
                            Triple(Icons.Rounded.Cookie, stringResource(R.string.privacy_shield_cookie_isolation), stringResource(R.string.privacy_shield_cookie_desc))
                        )
                        shields.forEachIndexed { index, (icon, title, subtitle) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (isDark) Color(0xFF707070) else Color(0xFFAAAAAA),
                                    modifier = Modifier.size(16.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = title,
                                        fontSize = 13.5.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = titleCol
                                    )
                                    Text(
                                        text = subtitle,
                                        fontSize = 11.sp,
                                        color = subCol,
                                        modifier = Modifier.padding(top = 1.dp)
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = stringResource(R.string.privacy_report_active),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            if (index < shields.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(0.5.dp)
                                        .padding(horizontal = 14.dp)
                                        .background(borderCol)
                                )
                            }
                        }
                    }
                }

                // ── Recently Blocked Trackers ────────────────────────────
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.privacy_report_recently_blocked),
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp,
                        color = labelCol
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(cardBg)
                            .border(0.5.dp, borderCol, RoundedCornerShape(14.dp))
                    ) {
                        val trackers = listOf(
                            Triple("google-analytics.com", stringResource(R.string.privacy_cat_analytics), 14),
                            Triple("doubleclick.net", stringResource(R.string.privacy_cat_advertising), 9),
                            Triple("connect.facebook.net", stringResource(R.string.privacy_cat_social), 6),
                            Triple("amazon-adsystem.com", stringResource(R.string.privacy_cat_retargeting), 4),
                            Triple("scorecardresearch.com", stringResource(R.string.privacy_cat_market_research), 2)
                        )
                        trackers.forEachIndexed { idx, (domain, category, count) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = domain,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = titleCol
                                    )
                                    Text(
                                        text = category,
                                        fontSize = 11.sp,
                                        color = subCol,
                                        modifier = Modifier.padding(top = 1.dp)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (isDark) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "$count",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isDark) Color(0xFFE5E5EA) else Color(0xFF1C1C1E)
                                    )
                                }
                            }
                            if (idx < trackers.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(0.5.dp)
                                        .padding(horizontal = 14.dp)
                                        .background(borderCol)
                                )
                            }
                        }
                    }
                }
            }
        }
        } // end outer background Column
    }

    if (showCustomizationSheet) {
        ModalBottomSheet(
            onDismissRequest = { onShowCustomizationSheetChange(false) },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color.White,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(top = 8.dp, bottom = 6.dp)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (viewModel.isDarkThemeEnabled) Color(0xFF3A3A3C) else Color(0xFFC7C7CC))
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 36.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                Text(
                    text = stringResource(R.string.customize_home_title),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                HorizontalDivider(color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                Spacer(Modifier.height(16.dp))

                // ── SECTION 1: WALLPAPERS & BACKGROUND ──────────────────────────
                Text(
                    text = stringResource(R.string.palette_section_wallpapers),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF2F2F7))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onShowCustomizationSheetChange(false)
                                onOpenWallpapers()
                            },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Wallpaper,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = stringResource(R.string.wallpaper_store_gallery),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                                )
                                Text(
                                    text = stringResource(R.string.wallpaper_store_gallery_desc),
                                    fontSize = 11.sp,
                                    color = Color(0xFF8E8E93)
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = Color(0xFF8E8E93),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    HorizontalDivider(color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                    // Wallpaper Dim Slider
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.wallpaper_dim_label),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = "${if (viewModel.wallpaperDim < 0) 0 else (viewModel.wallpaperDim * 100).toInt()}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = if (viewModel.wallpaperDim < 0) 0f else viewModel.wallpaperDim,
                            onValueChange = { viewModel.saveWallpaperDim(context, it) },
                            valueRange = 0f..0.8f,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Wallpaper Blur Slider
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.wallpaper_blur_label),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = "${viewModel.wallpaperBlur.toInt()} dp",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = viewModel.wallpaperBlur,
                            onValueChange = { viewModel.saveWallpaperBlur(context, it) },
                            valueRange = 0f..25f,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))

                // ── SECTION 2: ACCENT THEME COLOR ────────────────────────────
                Text(
                    text = stringResource(R.string.palette_section_accent),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF2F2F7))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val themes = listOf(
                        "Ocean Blue" to Color(0xFF0A84FF),
                        "Crimson Red" to Color(0xFFFF3B5C),
                        "Emerald Green" to Color(0xFF00C853),
                        "Sunset Orange" to Color(0xFFFF6D00),
                        "Royal Purple" to Color(0xFF7C4DFF),
                        "Monochrome" to Color(0xFFAAAAAA)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        themes.forEach { (name, color) ->
                            val isSelected = viewModel.selectedAccentTheme == name
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable { viewModel.saveAccentTheme(context, name) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                // ── SECTION 3: SHORTCUT TILE STYLE ────────────────────────────
                Text(
                    text = stringResource(R.string.palette_section_shortcut),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF2F2F7))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = stringResource(R.string.shortcut_shape_helper),
                        fontSize = 12.sp,
                        color = Color(0xFF8E8E93)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "Circle" to stringResource(R.string.style_circle),
                            "Squircle" to stringResource(R.string.style_squircle),
                            "Square" to stringResource(R.string.style_square),
                            "Glass" to stringResource(R.string.style_glass)
                        ).forEach { (style, label) ->
                            val isSelected = viewModel.shortcutTileStyle == style
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary
                                        else if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA)
                                    )
                                    .clickable { viewModel.saveShortcutTileStyle(context, style) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))

                // ── SECTION 4: LAYOUT SCALERS ─────────────────────────────────
                Text(
                    text = stringResource(R.string.palette_section_scalers),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF2F2F7))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Home Screen UI Scale
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.home_screen_ui_scale),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = "${(viewModel.homeUiScale * 100).toInt()}%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = viewModel.homeUiScale,
                            onValueChange = { newValue ->
                                val stepped = ((newValue / 0.05f) + 0.5f).toInt() * 0.05f
                                viewModel.saveHomeUiScale(context, stepped.coerceIn(0.8f, 1.3f))
                            },
                            valueRange = 0.8f..1.3f,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    HorizontalDivider(color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                    // App Nav Scaler (from Appearance Settings)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.app_nav_scaler),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = "${(viewModel.uiScale * 100).toInt()}%",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = viewModel.uiScale,
                            onValueChange = { newValue ->
                                val stepped = ((newValue / 0.05f) + 0.5f).toInt() * 0.05f
                                viewModel.saveUiScale(context, stepped.coerceIn(0.8f, 1.3f))
                            },
                            valueRange = 0.8f..1.3f,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))

                // ── SECTION 5: VISIBILITY TOGGLES ─────────────────────────────
                Text(
                    text = stringResource(R.string.palette_section_visibility),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF2F2F7))
                ) {
                    // Toggle: Show Logo
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.show_logo),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = stringResource(R.string.show_logo_desc),
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                        Switch(
                            checked = "section_logo" in viewModel.homeSectionsLayout,
                            onCheckedChange = { on ->
                                val l = viewModel.homeSectionsLayout
                                viewModel.saveHomeSectionsLayout(context, if (on) (l + "section_logo").distinct() else l - "section_logo")
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(start = 16.dp), color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                    // Toggle: Show Shortcuts
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.show_shortcuts),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = stringResource(R.string.show_shortcuts_desc),
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                        Switch(
                            checked = "section_shortcuts" in viewModel.homeSectionsLayout,
                            onCheckedChange = { on ->
                                val l = viewModel.homeSectionsLayout
                                viewModel.saveHomeSectionsLayout(context, if (on) (l + "section_shortcuts").distinct() else l - "section_shortcuts")
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(start = 16.dp), color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                    // Toggle: Show Recents
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.show_recents),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = stringResource(R.string.show_recents_desc),
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                        Switch(
                            checked = "section_recents" in viewModel.homeSectionsLayout,
                            onCheckedChange = { on ->
                                val l = viewModel.homeSectionsLayout
                                viewModel.saveHomeSectionsLayout(context, if (on) (l + "section_recents").distinct() else l - "section_recents")
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(start = 16.dp), color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                    // Toggle: Search bar at bottom (new home layout)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.home_search_bar_bottom),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = stringResource(R.string.home_search_bar_bottom_desc),
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                        Switch(
                            checked = viewModel.homeSearchBarAtBottom,
                            onCheckedChange = { viewModel.saveHomeSearchBarAtBottom(context, it) },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(start = 16.dp), color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                    // Toggle: Show Privacy Stats Widget
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.privacy_stats_widget),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = stringResource(R.string.privacy_stats_widget_desc),
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                        Switch(
                            checked = "section_privacy" in viewModel.homeSectionsLayout,
                            onCheckedChange = { on ->
                                val l = viewModel.homeSectionsLayout
                                viewModel.saveHomeSectionsLayout(context, if (on) (l + "section_privacy").distinct() else l - "section_privacy")
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(start = 16.dp), color = if (viewModel.isDarkThemeEnabled) Color(0xFF2C2C2E) else Color(0xFFE5E5EA))

                    // Toggle: Minimalist Focus Mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.minimalist_focus_mode),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E)
                            )
                            Text(
                                text = stringResource(R.string.minimalist_focus_mode_desc),
                                fontSize = 12.sp,
                                color = Color(0xFF8E8E93)
                            )
                        }
                        Switch(
                            checked = viewModel.isMinimalistFocusMode,
                            onCheckedChange = { viewModel.saveIsMinimalistFocusMode(context, it) },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

// ── Compact shortcut item: icon-only pill, no visible border box ────────────
// Mirrors Chrome/Aloha new-tab style — icon floats on a soft tinted circle,
// label underneath, whole thing feels light and airy.
// ── Home search field: shared by the top and bottom-docked layouts ──────────
@Composable
private fun HomeSearchField(
    viewModel: BrowserViewModel,
    searchText: androidx.compose.ui.text.input.TextFieldValue,
    onSearchTextChange: (androidx.compose.ui.text.input.TextFieldValue) -> Unit,
    onFocusChanged: (Boolean) -> Unit,
    onClear: () -> Unit,
    onLens: () -> Unit,
    onVoice: () -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    OutlinedTextField(
        value = searchText,
        onValueChange = onSearchTextChange,
        modifier = modifier.onFocusChanged { onFocusChanged(it.isFocused) },
        placeholder = { Text(stringResource(id = R.string.search_placeholder), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp) },
        leadingIcon = {
            var expanded by remember { mutableStateOf(false) }
            val currentEngine = viewModel.selectedSearchEngine
            val currentIconUrl = when (currentEngine) {
                "Google" -> "https://icons.duckduckgo.com/ip3/google.com.ico"
                "Yahoo" -> "https://icons.duckduckgo.com/ip3/yahoo.com.ico"
                "Yandex" -> "https://icons.duckduckgo.com/ip3/yandex.com.ico"
                "DuckDuckGo" -> "https://icons.duckduckgo.com/ip3/duckduckgo.com.ico"
                "Brave" -> "https://icons.duckduckgo.com/ip3/brave.com.ico"
                "Bing" -> "https://icons.duckduckgo.com/ip3/bing.com.ico"
                "Ecosia" -> "https://icons.duckduckgo.com/ip3/ecosia.org.ico"
                "Startpage" -> "https://icons.duckduckgo.com/ip3/startpage.com.ico"
                "Qwant" -> "https://icons.duckduckgo.com/ip3/qwant.com.ico"
                else -> null
            }

            Box {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { expanded = true },
                    contentAlignment = Alignment.Center
                ) {
                    if (currentIconUrl != null) {
                        coil.compose.AsyncImage(
                            model = coil.request.ImageRequest.Builder(LocalContext.current)
                                .data(currentIconUrl)
                                .size(48, 48)
                                .crossfade(true)
                                .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                                .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                                .build(),
                            contentDescription = currentEngine,
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape),
                            error = androidx.compose.ui.res.painterResource(id = android.R.drawable.ic_menu_search)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = currentEngine,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                    shape = RoundedCornerShape(16.dp),
                    containerColor = if (viewModel.isAmoledMode) Color(0xFF000000) else MaterialTheme.colorScheme.surface,
                    tonalElevation = 0.dp
                ) {
                    val engines = listOf("Google", "Yahoo", "Yandex", "DuckDuckGo", "Brave", "Bing", "Ecosia", "Startpage", "Qwant", "Custom")
                    engines.forEach { engine ->
                        val itemIconUrl = when (engine) {
                            "Google" -> "https://icons.duckduckgo.com/ip3/google.com.ico"
                            "Yahoo" -> "https://icons.duckduckgo.com/ip3/yahoo.com.ico"
                            "Yandex" -> "https://icons.duckduckgo.com/ip3/yandex.com.ico"
                            "DuckDuckGo" -> "https://icons.duckduckgo.com/ip3/duckduckgo.com.ico"
                            "Brave" -> "https://icons.duckduckgo.com/ip3/brave.com.ico"
                            "Bing" -> "https://icons.duckduckgo.com/ip3/bing.com.ico"
                            "Ecosia" -> "https://icons.duckduckgo.com/ip3/ecosia.org.ico"
                            "Startpage" -> "https://icons.duckduckgo.com/ip3/startpage.com.ico"
                            "Qwant" -> "https://icons.duckduckgo.com/ip3/qwant.com.ico"
                            else -> null
                        }

                        DropdownMenuItem(
                            leadingIcon = {
                                if (itemIconUrl != null) {
                                    coil.compose.AsyncImage(
                                        model = coil.request.ImageRequest.Builder(LocalContext.current)
                                            .data(itemIconUrl)
                                            .size(48, 48)
                                            .crossfade(true)
                                            .diskCachePolicy(coil.request.CachePolicy.ENABLED)
                                            .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
                                            .build(),
                                        contentDescription = engine,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .clip(CircleShape),
                                        error = androidx.compose.ui.res.painterResource(id = android.R.drawable.ic_menu_search)
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.Search,
                                        contentDescription = engine,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            text = { Text(engine, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp, fontWeight = FontWeight.Medium) },
                            onClick = {
                                viewModel.saveSearchEngine(context, engine)
                                expanded = false
                            },
                            colors = MenuDefaults.itemColors(
                                textColor = MaterialTheme.colorScheme.onSurface,
                                trailingIconColor = MaterialTheme.colorScheme.primary
                            ),
                            trailingIcon = {
                                if (currentEngine == engine) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = "Selected",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        )
                    }
                }
            }
        },
        trailingIcon = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(end = 4.dp)
            ) {
                if (searchText.text.isNotEmpty()) {
                    IconButton(onClick = onClear) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Clear search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onLens) {
                    Icon(
                        imageVector = Icons.Rounded.CameraAlt,
                        contentDescription = "Google Lens",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onVoice) {
                    Icon(
                        imageVector = Icons.Rounded.Mic,
                        contentDescription = "Voice Search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
        keyboardActions = KeyboardActions(onGo = { onSubmit() }),
        shape = RoundedCornerShape(24.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
            unfocusedTextColor = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF1F3F4),
            unfocusedContainerColor = if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF1F3F4)
        )
    )
}

/** Search suggestion list, shared by both home layouts. */
@Composable
private fun HomeSearchSuggestions(
    viewModel: BrowserViewModel,
    onSelectSuggestion: (String) -> Unit,
    onRefineSuggestion: (String) -> Unit,
    modifier: Modifier = Modifier,
    maxItems: Int = Int.MAX_VALUE
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = if (viewModel.isDarkThemeEnabled) Color(0xFF1C1C1E) else Color(0xFFF1F3F4),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            viewModel.searchSuggestions.take(maxItems).forEach { suggestion ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectSuggestion(suggestion) }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = suggestion,
                        color = if (viewModel.isDarkThemeEnabled) Color.White else Color(0xFF1C1C1E),
                        fontSize = 14.sp,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(
                        onClick = { onRefineSuggestion(suggestion) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.TrendingFlat,
                            contentDescription = "Refine search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .size(16.dp)
                                .graphicsLayer { rotationZ = -135f }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CompactShortcutItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isAccented: Boolean = false,
    tileStyle: String = "Circle",
    hasWallpaper: Boolean = false,
    onClick: () -> Unit
) {
    val tileShape: androidx.compose.ui.graphics.Shape = when (tileStyle) {
        "Squircle" -> RoundedCornerShape(14.dp)
        "Square"   -> RoundedCornerShape(6.dp)
        "Glass"    -> RoundedCornerShape(14.dp)
        else       -> CircleShape
    }
    val isGlass = tileStyle == "Glass"
    val tileBg = when {
        isAccented -> MaterialTheme.colorScheme.primary
        hasWallpaper || isGlass -> Color(0xFF101216).copy(alpha = 0.40f)
        else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
        modifier = Modifier
            .width(62.dp)
            .clickable(
                indication = null,
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(tileShape)
                .background(tileBg)
                .then(
                    if (hasWallpaper || isGlass) Modifier.border(0.5.dp, Color.White.copy(alpha = 0.18f), tileShape)
                    else Modifier
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isAccented || hasWallpaper) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(24.dp)
            )
        }
        Text(
            text = title,
            color = if (hasWallpaper) Color.White else MaterialTheme.colorScheme.onSurface,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
            letterSpacing = (-0.25).sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            style = androidx.compose.ui.text.TextStyle(
                shadow = if (hasWallpaper) androidx.compose.ui.graphics.Shadow(
                    color = Color.Black.copy(alpha = 0.85f),
                    offset = androidx.compose.ui.geometry.Offset(0f, 2f),
                    blurRadius = 4f
                ) else null
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun CompactDynamicShortcutItem(
    title: String,
    url: String,
    tileStyle: String = "Circle",
    hasWallpaper: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val domain = remember(url) {
        try { Uri.parse(url).host ?: url } catch (e: Exception) { url }
    }
    val faviconUrl = remember(domain) {
        if (domain.contains("rebelroot")) {
            "https://www.rebelroot.xyz/favicon.ico?v=${System.currentTimeMillis() / 86400000}"
        } else {
            "https://www.google.com/s2/favicons?sz=128&domain=$domain"
        }
    }
    val tileShape: androidx.compose.ui.graphics.Shape = when (tileStyle) {
        "Squircle" -> RoundedCornerShape(14.dp)
        "Square"   -> RoundedCornerShape(6.dp)
        "Glass"    -> RoundedCornerShape(14.dp)
        else       -> CircleShape
    }
    val isGlass = tileStyle == "Glass"
    val tileBg = when {
        hasWallpaper || isGlass -> Color(0xFF101216).copy(alpha = 0.40f)
        else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
        modifier = Modifier.width(62.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(tileShape)
                .background(tileBg)
                .then(
                    if (hasWallpaper || isGlass) Modifier.border(0.5.dp, Color.White.copy(alpha = 0.18f), tileShape)
                    else Modifier
                )
                .combinedClickable(onClick = onClick, onLongClick = onLongClick),
            contentAlignment = Alignment.Center
        ) {
            coil.compose.AsyncImage(
                model = coil.request.ImageRequest.Builder(LocalContext.current)
                    .data(faviconUrl)
                    .size(64, 64)
                    .crossfade(true)
                    .memoryCachePolicy(coil.request.CachePolicy.DISABLED)
                    .build(),
                contentDescription = title,
                modifier = Modifier.size(26.dp).clip(tileShape),
                error = androidx.compose.ui.res.painterResource(id = android.R.drawable.ic_menu_compass)
            )
        }
        Text(
            text = title,
            color = if (hasWallpaper) Color.White else MaterialTheme.colorScheme.onSurface,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
            letterSpacing = (-0.25).sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            style = androidx.compose.ui.text.TextStyle(
                shadow = if (hasWallpaper) androidx.compose.ui.graphics.Shadow(
                    color = Color.Black.copy(alpha = 0.85f),
                    offset = androidx.compose.ui.geometry.Offset(0f, 2f),
                    blurRadius = 4f
                ) else null
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun ShortcutItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isAccented: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.width(72.dp)
    ) {
        Surface(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(24.dp))
                .clickable { onClick() },
            color = if (isAccented) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
            border = if (isAccented) null else BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isAccented) Color.White else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun DiscoverRowItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
        
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun ToolCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isDarkTheme: Boolean = false,
    modifier: Modifier = Modifier,
    isCompact: Boolean = false,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.93f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "scale"
    )

    val bg = if (isDarkTheme) Color(0xFF2C2C2E) else Color(0xFFE5E5EA)
    val iconTint = if (isDarkTheme) Color(0xFFEAEAEA) else Color(0xFF202124)
    val textColor = if (isDarkTheme) Color(0xFFAEAEB2) else Color(0xFF3C3C43)

    // Compact (quick tools sheet): smaller tiles so a 4-column grid keeps
    // visible gutters even on small screens.
    val circleSize = if (isCompact) 44.dp else 62.dp
    val iconSize = if (isCompact) 18.dp else 26.dp
    val fontSize = if (isCompact) 10.sp else 12.sp
    val spacing = if (isCompact) 2.dp else 8.dp
    val cardWidth = if (isCompact) 64.dp else 80.dp

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(spacing),
        modifier = modifier
            .width(cardWidth)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        Box(
            modifier = Modifier
                .size(circleSize)
                .clip(CircleShape)
                .background(bg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(iconSize)
            )
        }
        Text(
            text = title,
            color = textColor,
            fontSize = fontSize,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun DynamicShortcutItem(
    title: String,
    url: String,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val domain = remember(url) {
        try {
            val uri = Uri.parse(url)
            uri.host ?: url
        } catch (e: Exception) {
            url
        }
    }
    val faviconUrl = "https://www.google.com/s2/favicons?sz=128&domain=$domain"

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.width(72.dp)
    ) {
        Surface(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(24.dp))
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick
                ),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                coil.compose.AsyncImage(
                    model = coil.request.ImageRequest.Builder(LocalContext.current)
                        .data(faviconUrl)
                        .size(64, 64)
                        .crossfade(true)
                        .build(),
                    contentDescription = title,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(32.dp)),
                    error = androidx.compose.ui.res.painterResource(id = android.R.drawable.ic_menu_compass)
                )
            }
        }
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun PopularSiteItem(
    title: String,
    domain: String,
    bgColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.width(72.dp)
    ) {
        Box(
            modifier = Modifier.size(64.dp)
        ) {
            Surface(
                modifier = Modifier
                    .size(54.dp)
                    .align(Alignment.BottomStart)
                    .clip(RoundedCornerShape(24.dp))
                    .clickable { onClick() },
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    val cleanDomain = domain.substringAfter("https://").substringBefore("/")
                    val faviconUrl = "https://www.google.com/s2/favicons?sz=128&domain=$cleanDomain"
                    
                    coil.compose.AsyncImage(
                        model = coil.request.ImageRequest.Builder(LocalContext.current)
                            .data(faviconUrl)
                            .size(64, 64)
                            .crossfade(true)
                            .build(),
                        contentDescription = title,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(24.dp)),
                        error = androidx.compose.ui.res.painterResource(id = android.R.drawable.ic_menu_compass)
                    )
                }
            }
            
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .align(Alignment.TopEnd),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Add,
                    contentDescription = "Add",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
